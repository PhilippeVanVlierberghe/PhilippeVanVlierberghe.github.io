/*
    This is where you put the data
 */
public class OldRobotBuilder implements RobotBuilder {
    public void setRobot(Robot robot) {
        this.robot = robot;
    }

    private Robot robot;

    public OldRobotBuilder()
    {
        this.robot = new Robot();
    }

    @Override
    public void buildRobotHead() {
        robot.setRobotHead("tin");
    }

    @Override
    public void buildRobotTorso() {
        robot.setRobotTorso("steel");
    }

    @Override
    public void buildRobotArms() {
        robot.setRobotArms("iron mace");
    }

    @Override
    public void buildRobotLegs() {
        robot.setRobotLegs("big weels");
    }

    @Override
    public Robot getRobot() {
        return this.robot;
    }
}
