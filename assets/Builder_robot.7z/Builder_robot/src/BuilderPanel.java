import javax.swing.*;
import java.awt.*;

public class BuilderPanel extends JPanel {
    private JButton bBuild = new JButton("Build my robot.");
    private JTextField tRobotHead = new JTextField();
    private JTextField tRobotArms = new JTextField();
    private JTextField tRobotTorso = new JTextField();
    private JTextField tRobotLegs = new JTextField();
    private JTextArea aResult = new JTextArea();
    private JScrollPane scroll = new JScrollPane(aResult);
    private RobotBuilder oldStyleRobot = new OldRobotBuilder();
    private RobotEngineer robotEngineer = new RobotEngineer(oldStyleRobot);


    public BuilderPanel()
    {
        robotEngineer.makerobot();
        tRobotHead.setText(robotEngineer.getRobot().getRobotHead());
        tRobotArms.setText(robotEngineer.getRobot().getRobotArms());
        tRobotTorso.setText(robotEngineer.getRobot().getRobotTorso());
        tRobotLegs.setText(robotEngineer.getRobot().getRobotLegs());

        //set size of components
        setLayout(new GridLayout(6,0));
        tRobotHead.setSize(132,25);
        tRobotArms.setSize(132,25);
        tRobotTorso.setSize(132,25);
        tRobotLegs.setSize(132,25);
        bBuild.setSize(132,25);
        scroll.setSize( 100, 100 );

        //set actionListener
        bBuild.addActionListener( e->
        {
            robotEngineer.getRobot().setRobotHead(tRobotHead.getText());
            tRobotHead.setText(robotEngineer.getRobot().getRobotHead());
            robotEngineer.getRobot().setRobotArms(tRobotArms.getText());
            tRobotArms.setText(robotEngineer.getRobot().getRobotArms());
            robotEngineer.getRobot().setRobotArms(tRobotArms.getText());
            tRobotArms.setText(robotEngineer.getRobot().getRobotArms());
            robotEngineer.getRobot().setRobotTorso(tRobotTorso.getText());
            tRobotTorso.setText(tRobotTorso.getText());
            robotEngineer.getRobot().setRobotLegs(tRobotLegs.getText());
            tRobotLegs.setText(tRobotLegs.getText());
            //robotEngineer.makerobot(); //create new robot
            aResult.setText("");
            aResult.append("Your Robot has been build: \n");
            aResult.append(robotEngineer.getRobot().toString());
        });

        //setup panel
        this.add(tRobotHead);
        this.add(tRobotArms);
        this.add(tRobotTorso);
        this.add(tRobotLegs);
        this.add(bBuild);
//this.add(textArea); // get rid of this
        this.add(scroll);
        this.add(scroll);
        this.setVisible(true);
    }
}
