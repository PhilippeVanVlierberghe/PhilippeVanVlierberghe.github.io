public class Robot implements RobotPlan {
    private String robotHead,robotTorso,robotArms,robotLegs;

    @Override
    public void setRobotHead(String head) {
        robotHead = head;
    }

    @Override
    public void setRobotTorso(String torso) {
        robotTorso = torso;
    }

    @Override
    public void setRobotArms(String arms) {
        robotArms = arms;
    }

    @Override
    public void setRobotLegs(String legs) {
        robotLegs = legs;
    }

    public String getRobotHead()
    {
        return robotHead;
    }

    public String getRobotTorso() {
        return robotTorso;
    }

    public String getRobotArms() {
        return robotArms;
    }

    public String getRobotLegs() {
        return robotLegs;
    }

    public String toString()
    {
        String aResult =("It has a(n) "+ getRobotHead() + " head \n"
        + robotArms + " arms \n"
        + "a(n) " + robotTorso + " torso \n"
        + "and " + robotLegs + " for legs.");
        System.out.println("in Robot class: " +robotHead+"\n ------ \n");
        System.out.println("in Robot class: " +aResult);
        return aResult;
    }
}
