import javax.swing.JFrame;

public class Main {
// alleen de builder kent het te maken object
    public static void main(String[] args) {
        /*
        System.out.println("Robot was build");
        System.out.println(firstRobot.getRobotHead());
        System.out.println( firstRobot.getRobotArms());
        System.out.println(firstRobot.getRobotTorso());
        System.out.println(firstRobot.getRobotLegs());
*/
        JFrame f = new JFrame("Robot builder");
        BuilderPanel bp = new BuilderPanel();

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.add(bp);
        f.setSize(310,280);
        f.setResizable(false);
        f.setVisible(true);

    }
}
