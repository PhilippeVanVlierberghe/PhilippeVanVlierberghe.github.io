

<?php $__env->startSection('content'); ?>
    <div class="rowExtra">
        <div class="col-md-12">
            <p class="quote"><?php echo e($post->title); ?></p>
        </div>
    </div>
    <div class="rowExtra">
        <div class="col-md-12">
            <p><?php echo e(count($post->likes)); ?> Likes |   
            <a href="<?php echo e(route('blog.post.like',['id' =>$post->id])); ?>">Like</a></p>
        </div>
    </div>
    <div class="rowExtra">
        <div class="col-md-12">
            <p><?php echo e($post->content); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PHP projects\pluralsightPHPLaravel\Models and Data\laravel\resources\views/blog/post.blade.php ENDPATH**/ ?>