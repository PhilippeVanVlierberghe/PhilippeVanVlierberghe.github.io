<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('blog.index')); ?>">Laravel Guide</a>
            <ul class="nav navbar-nav">
                <li class="active"><a href="<?php echo e(route('admin.index')); ?>">Posts</a></li>
            </ul>
        </div>
    </div><!-- /.container-fluid -->
</nav>
<?php /**PATH C:\xampp\htdocs\PHP projects\pluralsightPHPLaravel\The Basics\laravel\resources\views/partials/admin-header.blade.php ENDPATH**/ ?>