

<?php $__env->startSection('content'); ?>
    <div class='container'>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-registration-create')->html();
} elseif ($_instance->childHasBeenRendered('0mPF9ue')) {
    $componentId = $_instance->getRenderedChildComponentId('0mPF9ue');
    $componentTag = $_instance->getRenderedChildComponentTagName('0mPF9ue');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0mPF9ue');
} else {
    $response = \Livewire\Livewire::mount('customer-registration-create');
    $html = $response->html();
    $_instance->logRenderedChild('0mPF9ue', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/customer/create.blade.php ENDPATH**/ ?>