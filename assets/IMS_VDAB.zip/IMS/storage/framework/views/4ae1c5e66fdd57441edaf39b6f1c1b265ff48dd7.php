<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Admin message</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(!Auth::check()): ?>
                    <p>
                        <?php echo e('Meldt u aan of maak een gebruikersaccount aan om dit programma te gebruiken.'); ?>

                    </p>
                    <br>
                <?php else: ?>
                    <p>
                        <?php echo e('Bedankt dat u ons uw bedrijf toevertrouwd.'); ?>

                    </p>
                <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/home.blade.php ENDPATH**/ ?>