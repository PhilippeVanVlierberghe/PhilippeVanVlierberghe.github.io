<div class="row form-group-container">
    <div class="col-sm">
        <div class="form-group">
            <label for="documentType"><?php echo e(__('Document type')); ?>:</label>
            <br>
            <select wire:model="documentType" name="documentType" id="documentType" required>
                <option value=""><?php echo e(__('Choose an option')); ?></option>
                <option value="FA"><?php echo e(__('Invoice')); ?></option>
                <option value="OF"><?php echo e(__('Quotation')); ?></option>
            </select>
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="documentDate"><?php echo e(__('Date')); ?>:</label>
            <br>
            <input wire:model="documentDate" type="date" id="documentDate" name="documentDate"
                value="<?php echo e(date('Y-m-d')); ?>" required>
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="documentDueDateDays"><?php echo e(__('Expiry date')); ?>:</label>
            <br>
            <input type="date" id="documentDueDateDays" name="documentDueDateDays">
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="document_code"><?php echo e($strDocumentNr); ?>:</label>
            <br>
            <input type="text" minlength="11" name="document_code" id="document_code"
                value="<?php echo e($lastDocument_code); ?>" readonly>
        </div>

    </div>

    <div class="col-sm">
        <div class="form-group">
            <label for="customerId"><?php echo e(__('Customer')); ?>:</label>
            <br>
            <select name="customerId" id="customerId">
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($customer->id); ?>">
                        <?php echo e($customer->getCustomerName()); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <br>
    <div class="col-sm">
        <div class="form-group">
            <label for="isMedecontractant"><?php echo e(__('Is a co-contractor')); ?>:</label>
            <br>
            <input type="checkbox" id="isMedecontractant" name="isMedecontractant">
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/livewire/document-number.blade.php ENDPATH**/ ?>