

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('invoice.create')); ?>" method="post">
            <div class="container">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('document-number', ['customers' => $customers])->html();
} elseif ($_instance->childHasBeenRendered('sJioF6h')) {
    $componentId = $_instance->getRenderedChildComponentId('sJioF6h');
    $componentTag = $_instance->getRenderedChildComponentTagName('sJioF6h');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sJioF6h');
} else {
    $response = \Livewire\Livewire::mount('document-number', ['customers' => $customers]);
    $html = $response->html();
    $_instance->logRenderedChild('sJioF6h', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <br />
                <div class="row justify-content-center">
                    <div class="col">
                        <div class="form-group">
                            <div class="tableContainer">
                                <div class="scroll">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th class="tableHidden"><label for="invoiceItem_id[]"></label></th>
                                                <th><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                                        fill="currentColor" class="bi bi-check" viewBox="0 0 16 16">
                                                        <path
                                                            d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                                                    </svg></th>
                                                <th><?php echo e(__('Service')); ?></th>
                                                <th><?php echo e(__('Explanation')); ?></th>
                                                <th><?php echo e(__('Price')); ?> €</th>
                                                <th><?php echo e(__('VAT')); ?> %</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $invoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoiceItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td class="tableHidden">
                                                        <label for="invoiceItem_add[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_id[<?php echo e($key); ?>]</label>
                                                        <input class="tableHidden" type="text"
                                                            id="invoiceItem_id[<?php echo e($key); ?>]" name="invoiceItem_id[]"
                                                            title="id<?php echo e($key); ?>" value="<?php echo e($invoiceItem->id); ?>">
                                                    </td>
                                                    <td class="ExtrasmallTableField">
                                                        <label for="invoiceItem_add[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_add[<?php echo e($key); ?>]</label>
                                                        <input class="form-check-input" type="checkbox"
                                                            name="invoiceItem_add[<?php echo e($key); ?>]"
                                                            id="invoiceItem_add[<?php echo e($key); ?>]">
                                                    </td>
                                                    <td>
                                                        <label for="invoiceItem_title[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_title[<?php echo e($key); ?>]</label>
                                                        <input class="col-sm-4" type="text"
                                                            id="invoiceItem_title[<?php echo e($key); ?>]"
                                                            name="invoiceItem_title[<?php echo e($key); ?>]"
                                                            title="title[<?php echo e($key); ?>]"
                                                            value="<?php echo e($invoiceItem->title); ?>">
                                                    </td>
                                                    <td>
                                                        <label for="invoiceItem_descriptions[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_descriptions[<?php echo e($key); ?>]</label>
                                                        <textarea rows="3" cols="50" id="invoiceItem_descriptions[<?php echo e($key); ?>]"
                                                            name="invoiceItem_descriptions[<?php echo e($key); ?>]"><?php echo str_replace('<br />', "\n", $invoiceItem->descriptions); ?></textarea>
                                                    </td>
                                                    <td class="smallTableField">
                                                        <label for="invoiceItem_unitPrice[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_unitPrice[<?php echo e($key); ?>]</label>
                                                        <input class="col-sm-4" type="number" step="0.5"
                                                            id="invoiceItem_unitPrice[<?php echo e($key); ?>]"
                                                            name="invoiceItem_unitPrice[<?php echo e($key); ?>]"
                                                            title="unitPrice[<?php echo e($key); ?>]"
                                                            value="<?php echo e($invoiceItem->unitPrice); ?>">
                                                    </td>
                                                    <td class="smallTableField">
                                                        <label for="invoiceItem_taxPercentageAsInt[<?php echo e($key); ?>]"
                                                            hidden>invoiceItem_taxPercentageAsInt[<?php echo e($key); ?>]</label>
                                                        <input class="col-sm-2" type="number" step="0.5"
                                                            id="invoiceItem_taxPercentageAsInt[<?php echo e($key); ?>]"
                                                            name="invoiceItem_taxPercentageAsInt[<?php echo e($key); ?>]"
                                                            title="tax percentage[<?php echo e($key); ?>]"
                                                            value="<?php echo e($invoiceItem->taxPercentageAsInt); ?>">
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><br />

            <div class="form-group">
                <label for="notes"><?php echo e(__('Comments')); ?> (<?php echo e(__('Optional')); ?>):</label>
                <textarea id="notes" class="form-control" name="notes" rows="4"></textarea>
            </div>
            <?php echo e(csrf_field()); ?>

            <br />
            <button type="submit" class="btn btn-primary" formaction="<?php echo e(route('invoice.preview')); ?>"
                formtarget="_blank">Preview</button>
            <hr>
            <button type="submit" class="btn btn-primary"><?php echo e(__('Create document')); ?></button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/vendor/invoices/createInvoice.blade.php ENDPATH**/ ?>