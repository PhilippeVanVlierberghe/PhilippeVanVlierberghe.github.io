

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="<?php echo e(route('serviceItem.create')); ?>" method="post">
                    <div class="form-group">
                        <label for="title">Dienst</label>
                        <input type="text" class="form-control" id="title" name="title">
                        <?php if($errors->has('title')): ?>
                            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="descriptions">Toelichting</label>
                        <textarea id="descriptions" class="form-control" name="descriptions" rows="4"></textarea>
                        <?php if($errors->has('descriptions')): ?>
                            <span class="text-danger"><?php echo e($errors->first('descriptions')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="unitPrice">Prijs</label>
                        <input type="text" class="form-control" id="unitPrice" name="unitPrice">
                        <?php if($errors->has('unitPrice')): ?>
                            <span class="text-danger"><?php echo e($errors->first('unitPrice')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="taxPercentageAsInt">BTW %</label>
                        <input type="text" class="form-control" id="taxPercentageAsInt" name="taxPercentageAsInt">
                        <?php if($errors->has('taxPercentageAsInt')): ?>
                            <span class="text-danger"><?php echo e($errors->first('taxPercentageAsInt')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php echo e(csrf_field()); ?>

                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/serviceItem/create.blade.php ENDPATH**/ ?>