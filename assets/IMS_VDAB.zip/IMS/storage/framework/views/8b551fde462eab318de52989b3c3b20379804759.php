

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('customer-registration-update', ['customer' => $customer])->html();
} elseif ($_instance->childHasBeenRendered('5L68slR')) {
    $componentId = $_instance->getRenderedChildComponentId('5L68slR');
    $componentTag = $_instance->getRenderedChildComponentTagName('5L68slR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5L68slR');
} else {
    $response = \Livewire\Livewire::mount('customer-registration-update', ['customer' => $customer]);
    $html = $response->html();
    $_instance->logRenderedChild('5L68slR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/customer/edit.blade.php ENDPATH**/ ?>