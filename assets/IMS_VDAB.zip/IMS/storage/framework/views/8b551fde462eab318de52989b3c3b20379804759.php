

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="<?php echo e(route('customer.update')); ?>" method="post">
                    <div class="form-group">
                        <label for="firstName">Voornaam</label>
                        <input type="text" class="form-control" id="firstName" name="firstName" value="<?php echo e($customer->firstName); ?>">
                        <?php if($errors->has('firstName')): ?>
                            <span class="text-danger"><?php echo e($errors->first('firstName')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="lastName">Familienaam</label>
                        <input type="text" class="form-control" id="lastName" name="lastName" value="<?php echo e($customer->lastName); ?>">
                        <?php if($errors->has('lastName')): ?>
                            <span class="text-danger"><?php echo e($errors->first('lastName')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="VATnumber">ondernemingsnummer</label>
                        <input type="text" class="form-control" id="VATnumber" name="VATnumber" value="<?php echo e($customer->VATnumber); ?>">
                        <?php if($errors->has('VATnumber')): ?>
                            <span class="text-danger"><?php echo e($errors->first('VATnumber')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="address">Adres</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo e($customer->address); ?>">
                        <?php if($errors->has('address')): ?>
                            <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="zip">Postcode</label>
                        <input type="text" class="form-control" id="zip" name="zip" value="<?php echo e($customer->zip); ?>">
                        <?php if($errors->has('zip')): ?>
                            <span class="text-danger"><?php echo e($errors->first('zip')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="residence">Woonplaats</label>
                        <input type="text" class="form-control" id="residence" name="residence" value="<?php echo e($customer->residence); ?>">
                        <?php if($errors->has('residence')): ?>
                            <span class="text-danger"><?php echo e($errors->first('residence')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" id="email" name="email" value="<?php echo e($customer->email); ?>">
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefoon</label>
                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($customer->phone); ?>">
                        <?php if($errors->has('phone')): ?>
                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" value="<?php echo e($customerId); ?>">
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/customer/edit.blade.php ENDPATH**/ ?>