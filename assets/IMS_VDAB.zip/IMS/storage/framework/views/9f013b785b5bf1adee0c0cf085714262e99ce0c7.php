

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="tableContainer">
            <div class="container">
                <div class="row">
                    <div class="col-sm">
                        <form class="form-inline" method="GET">
                            <div class="form-group">
                                <label for="filterDocumentType" class="col-form-label">Document type:</label>
                                <br>
                                <select name="filterDocumentType" id="filterDocumentType" onchange="this.form.submit()">
                                    <option value="" disabled selected>Kies een documenttype...</option>
                                    <option value="FA">Factuur</option>
                                    <option value="OF">Offerte</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm">
                        <form class="form-inline" method="GET">
                            <div class="form-group">
                                <label for="filterDocCode" class="col-form-label">Document code:</label>
                                <br>
                                <input type="text" class="form-control" id="filterDocCode" name="filterDocCode"
                                    placeholder="Document code..." value="<?php echo e($filterDocCode); ?>">
                            </div>
                        </form>
                    </div>
                    <div class="col-sm">
                        <form class="form-inline" method="GET">
                            <div class="form-group">
                                <label for="filterDocumentDate" class="col-form-label">Datum ( jaar-maand-dag ):</label>
                                <br>
                                <input type="text" class="form-control" id="filterDocumentDate" name="filterDocumentDate"
                                    placeholder="Datum..." value="<?php echo e($filterDocumentDate); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <br>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentType', 'Document'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentDate', 'Jaar'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentDate', 'Datum'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('document_code', 'Code [PDF]'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.firstName', 'Klant'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('customer.VATnumber', 'Ondernemingsnummer'));?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($document->id); ?></th>
                                <td><?php echo e(Str::swap(['FA' => 'Factuur','OF'=>'Offerte'],$document->documentType)); ?></td>
                                <td><?php echo e(substr($document->documentDate, 0, 4)); ?></td>
                                <td><?php echo e($document->documentDate); ?></td>
                                <td><a target="_blank"
                                        href="<?php echo e(route('invoice.document', ['id' => $document->id])); ?>"><?php echo e($document->document_code); ?></a>
                                </td>
                                <td><?php echo e($document->customer->getFullName()); ?></td>
                                <td><?php echo e($document->customer->VATnumber); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-primary" href="<?php echo e(route('invoice.zip')); ?>">Export naar zip</a>
            <div class="paginationContainer">
                <div><?php echo e($documents->appends($_GET)->links('partials.custom_pagination')); ?></div>
            </div>
            <p>U ziet <?php echo e($documents->count()); ?> van de <?php echo e($documents->total()); ?> document(en).</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/vendor/invoices/table.blade.php ENDPATH**/ ?>