

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="tableContainer">
            <div class="container">
                <form class="form-inline" method="GET">

                    <div class="row">
                        <div class="col-sm">
                            <div class="form-group">
                                <label for="filterDocumentType" class="col-form-label"><?php echo e(__('Document type')); ?>:</label>
                                <br>
                                <select name="filterDocumentType" id="filterDocumentType">
                                    <option value="" disabled selected><?php echo e(__('Choose an option')); ?></option>
                                    <option value="FA"><?php echo e(__('Invoice')); ?></option>
                                    <option value="OF"><?php echo e(__('Quotation')); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm">
                            <div class="form-group">
                                <label for="filterDocCode" class="col-form-label"><?php echo e(__('Document code')); ?>:</label>
                                <br>
                                <input type="text" class="form-control" id="filterDocCode" name="filterDocCode"
                                    placeholder="<?php echo e(trans('Document code').'...'); ?>" value="<?php echo e($filterDocCode); ?>">
                            </div>
                        </div>

                        <div class="col-sm">
                            <div class="form-group">
                                <label for="filterDocumentDateFrom" class="col-form-label"><?php echo e(__('From')); ?>:</label>
                                <br>
                                <input type="date" class="form-control" id="filterDocumentDateFrom"
                                    name="filterDocumentDateFrom" placeholder="Datum..."
                                    value="<?php echo e($filterDocumentDateFrom); ?>">
                                <br>
                                <label for="filterDocumentDateUntil" class="col-form-label"><?php echo e(__('Until')); ?>:</label>
                                <br>
                                <input type="date" class="form-control" id="filterDocumentDateUntil"
                                    name="filterDocumentDateUntil" placeholder="Datum..."
                                    value="<?php echo e($filterDocumentDateUntil); ?>">
                            </div>
                        </div>
                    </div>
                    <br>
                    <input class="btn btn-primary" type="submit" value="<?php echo e(trans('Filter the data')); ?>">

                </form>

            </div>
            <br>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentType', trans('Document type')));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentDate', trans('Year')));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('documentDate', trans('Date')));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('document_code', 'Code [PDF]'));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('firstName', trans('Customer')));?></th>
                            <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('VATnumber', trans('Company number')));?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($document->id); ?></th>
                                <td><?php echo e(Str::swap(['FA' => 'Factuur', 'OF' => 'Offerte'], $document->documentType)); ?></td>
                                <td><?php echo e(date_format(date_create($document->documentDate),"Y")); ?></td>
                                <td><?php echo e(date_format(date_create($document->documentDate),"d/m/Y")); ?></td>
                                <td><a target="_blank"
                                        href="<?php echo e(route('invoice.document', ['id' => $document->id])); ?>"><?php echo e($document->document_code); ?></a>
                                </td>
                                <td><?php echo e($document->getCustomerName()); ?></td>
                                <td><?php echo e($document->VATnumber); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-primary" href="<?php echo e(route('invoice.zip')); ?>"><?php echo e(__('Export to zip')); ?></a>
            <div class="paginationContainer">
                <div><?php echo e($documents->appends($_GET)->links('partials.custom_pagination')); ?></div>
            </div>
            
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/vendor/invoices/table.blade.php ENDPATH**/ ?>