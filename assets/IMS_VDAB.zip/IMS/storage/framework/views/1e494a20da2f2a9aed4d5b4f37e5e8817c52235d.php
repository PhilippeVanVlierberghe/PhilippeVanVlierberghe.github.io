

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="<?php echo e(route('serviceItem.update')); ?>" method="post">
                    <div class="form-group">
                        <label for="title"><?php echo e(__('Service')); ?></label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo e($serviceItem->title); ?>">
                        <?php if($errors->has('title')): ?>
                            <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="descriptions"><?php echo e(__('Explanation')); ?></label>
                        <textarea id="descriptions" class="form-control" name="descriptions"
                            rows="4"><?php echo e($serviceItem->descriptions); ?></textarea>
                        <?php if($errors->has('descriptions')): ?>
                            <span class="text-danger"><?php echo e($errors->first('descriptions')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="unitPrice"><?php echo e(__('Price')); ?></label>
                        <input type="text" class="form-control" id="unitPrice" name="unitPrice"
                            value="<?php echo e($serviceItem->unitPrice); ?>">
                        <?php if($errors->has('unitPrice')): ?>
                            <span class="text-danger"><?php echo e($errors->first('unitPrice')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="taxPercentageAsInt"><?php echo e(__('VAT')); ?> %</label>
                        <input type="text" class="form-control" id="taxPercentageAsInt" name="taxPercentageAsInt"
                            value="<?php echo e($serviceItem->taxPercentageAsInt); ?>">
                        <?php if($errors->has('taxPercentageAsInt')): ?>
                            <span class="text-danger"><?php echo e($errors->first('taxPercentageAsInt')); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="id" value="<?php echo e($serviceItem_id); ?>">

                    <br>
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Submit')); ?></button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/serviceItem/edit.blade.php ENDPATH**/ ?>