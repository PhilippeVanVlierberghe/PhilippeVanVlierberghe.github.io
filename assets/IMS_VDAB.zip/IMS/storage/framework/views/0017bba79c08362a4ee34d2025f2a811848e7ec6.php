

<?php $__env->startSection('content'); ?>
    <div class="container">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda commodi illum nobis nostrum numquam officiis
            possimus provident rem repellat sint? Dicta eligendi eum hic, labore nisi non quidem quos voluptates.
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa debitis magni modi nihil numquam odit pariatur
            recusandae repellendus sint voluptates. Blanditiis expedita minus nostrum numquam placeat porro praesentium quae
            soluta!</p>
            <?php for($i = 65; $i < 77; $i++): ?>
                <a href="<?php echo e(URL::to('img/img'.chr($i).'.jpg')); ?>" target="_blank">
                <img class="aboutImg" src="<?php echo e(URL::to('img/img'.chr($i).'.jpg')); ?>" alt="test">
                </a>
            <?php endfor; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/other/about.blade.php ENDPATH**/ ?>