<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">

        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img id="logo"
                src="<?php echo e(URL::to('vendor/invoices/logo.gif')); ?>" alt="logo" height="100"></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active"><a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                <?php if(!Auth::check()): ?>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link"
                            href="<?php echo e(route('invoice.create')); ?>"><?php echo e(__('Documents')); ?></a></li>
                    <li class="nav-item"><a class="nav-link"
                            href="<?php echo e(route('customer.table')); ?>"><?php echo e(__('Customers')); ?></a></li>
                    <li class="nav-item"><a class="nav-link"
                            href="<?php echo e(route('serviceItem.table')); ?>"><?php echo e(__('Services')); ?></a>
                    </li>
                    <li class="nav-item"><a class="nav-link"
                            href="<?php echo e(route('invoice.table')); ?>"><?php echo e(__('History')); ?></a></li>
                    <li class="nav-item"><a id="logout" class="nav-link" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">
                            <?php echo e(__('Logout')); ?>

                        </a>
                    </li>
                    <li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <form action="<?php echo e(route('locale.setting')); ?>" method="GET">
        <?php if(!session('lan')): ?>
            <label for="lan"> <img class="lanImg" src="<?php echo e(URL::to('img/nl.svg')); ?>" alt="language" /></label>
        <?php else: ?>
            <label for="lan"> <img class="lanImg" src="<?php echo e(URL::to('img/' . session('lan') . '.svg')); ?>"
                    alt="language" /></label>
        <?php endif; ?>        <select name="lan" id="lan" onchange="this.form.submit()">
            <option value=""><?php echo e(__('Lan')); ?></option>
            <option value="nl">NL </option>
            <option value="en">EN </option>
            <option value="fr">FR </option>
        </select>
    </form>
</nav>
<?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/partials/header.blade.php ENDPATH**/ ?>