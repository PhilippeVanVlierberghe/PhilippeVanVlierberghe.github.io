<form action='<?php echo e(route('customer.create')); ?>' method='post'>
    <div class='form-group'>
        <label for='firstName'><?php echo e(__('Firstname')); ?></label>
        <input wire:model='firstName' type='text' class='form-control' id='firstName' name='firstName'
            <?php if($fliedCheck1): ?> readonly <?php endif; ?>>
        <?php if($errors->has('firstName')): ?>
            <span class='text-danger'><?php echo e($errors->first('firstName')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='lastName'><?php echo e(__('Lastname')); ?></label>
        <input wire:model='lastName' type='text' class='form-control' id='lastName' name='lastName'
            <?php if($fliedCheck1): ?> readonly <?php endif; ?>>
        <?php if($errors->has('lastName')): ?>
            <span class='text-danger'><?php echo e($errors->first('lastName')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='company'><?php echo e(__('Company')); ?></label>
        <input wire:model='company' type='text' class='form-control' id='company' name='company'
            <?php if($fliedCheck2): ?> readonly <?php endif; ?>>
        <?php if($errors->has('company')): ?>
            <span class='text-danger'><?php echo e($errors->first('company')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='VATnumber'><?php echo e(__('Company number')); ?></label>
        <input wire:model='VATnumber' type='text' class='form-control' id='VATnumber' name='VATnumber'
            <?php if($fliedCheck2): ?> readonly <?php endif; ?>>
        <?php if($errors->has('VATnumber')): ?>
            <span class='text-danger'><?php echo e($errors->first('VATnumber')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='address'><?php echo e(__('Address')); ?></label>
        <input type='text' class='form-control' id='address' name='address'>
        <?php if($errors->has('address')): ?>
            <span class='text-danger'><?php echo e($errors->first('address')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='zip'><?php echo e(__('Zip code')); ?></label>
        <input type='text' class='form-control' id='zip' name='zip'>
        <?php if($errors->has('zip')): ?>
            <span class='text-danger'><?php echo e($errors->first('zip')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='residence'><?php echo e(__('Residence')); ?></label>
        <input type='text' class='form-control' id='residence' name='residence'>
        <?php if($errors->has('residence')): ?>
            <span class='text-danger'><?php echo e($errors->first('residence')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='email'><?php echo e(__('Email')); ?></label>
        <input type='text' class='form-control' id='email' name='email'>
        <?php if($errors->has('email')): ?>
            <span class='text-danger'><?php echo e($errors->first('email')); ?></span>
        <?php endif; ?>
    </div>
    <div class='form-group'>
        <label for='phone'><?php echo e(__('Phone')); ?></label>
        <input type='text' class='form-control' id='phone' name='phone'>
        <?php if($errors->has('phone')): ?>
            <span class='text-danger'><?php echo e($errors->first('phone')); ?></span>
        <?php endif; ?>
    </div>
    <?php echo e(csrf_field()); ?>

    <br>
    <button type='submit' class='btn btn-primary'><?php echo e(__('Submit')); ?></button>
</form>
<?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/livewire/customer-registration-create.blade.php ENDPATH**/ ?>