<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterCustomerUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return             [
            'firstName' => 'nullable|min:2|required_without:company',
            'lastName' => 'nullable|min:2|required_without:company',
            'company' => 'nullable|min:2|required_without:firstName',
            'VATnumber' => 'nullable|required_without:firstName|unique:customers,VATnumber,' . $this->input('id'),
            'address' => 'required|min:2',
            'residence' => 'required|min:2',
            'zip' => 'required|alpha_num',
            'email' => 'nullable|email|unique:customers,email,' . $this->input('id'),
            'phone' => 'nullable|unique:customers,phone,' . $this->input('id')
        ];
    }

    public function messages()
    {
        return             [
            'firstName.min:2' => __('validation.min.string'),
            'lastName.min:2' => __('validation.min.string'),
            'validation.required_without' =>__('validation.required_without'),
            'company.min:2' => __('validation.min.string'),
            'address.required' => __('required'),
            'residence.required' => __('required'),
            'zip.required' => __('required'),
            'email.unique' => __('unique'),
            'VATnumber.unique' => __('unique'),
            'phone.unique' => __('unique'),
        ];
    }
}
