<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterServiceUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'title' => 'required',
            'descriptions' => 'nullable|starts_with:-,–',
            'unitPrice' => 'required',
            'taxPercentageAsInt' => 'required|integer'
        ];
    }

    public function messages()
    {
        return [
            'title.required' => __('required'),
            'descriptions.starts_with' => __('starts_with'),
            'unitPrice.required' => __('required'),
            'unitPrice.numeric' => __('numeric'),
            'taxPercentageAsInt.required' => __('required'),
        ];
    }
}
