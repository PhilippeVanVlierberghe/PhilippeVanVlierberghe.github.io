<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateInvoiceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return [
            'document_code' => 'required|unique:documents',
            'documentType' => 'required|min:2',
            'documentDate' => 'required',
            'notes' => 'nullable'
        ];
    }

    public function messages()
    {
        return [
            'documetType.min:2' => __('validation.min.string'),
            'documentType.required' => __('required'),
            'document_code.unique' => __('unique'),
            'document_code.required' => __('required'),
        ];
    }
}
