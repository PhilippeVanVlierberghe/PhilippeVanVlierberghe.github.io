<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegisterCustomerCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        return             [
            'firstName' => 'nullable|min:2|required_without:company',
            'lastName' => 'nullable|min:2|required_without:company',
            'company' => 'nullable|min:2|required_without:firstName',
            'VATnumber' => 'nullable|unique:customers|required_without:firstName',
            'address' => 'required|min:2',
            'residence' => 'required|min:2',
            'zip' => 'required|alpha_num',
            'email' => 'nullable|email|unique:customers',
            'phone' => 'nullable|unique:customers'
        ];
    }
    
    public function messages()
    {
        return [
            'firstName.min:2' => __('validation.min.string'),
            'validation.required_without' =>__('validation.required_without'),
            'lastName.min:2' => __('validation.min.string'),
            'company.min:2' => __('validation.min.string'),
            'address.required' => __('required'),
            'residence.required' => __('required'),
            'zip.required' => __('required'),
            'email.unique' => __('unique'),
            'VATnumber.unique' => __('unique'),
            'phone.unique' => __('unique'),
        ];
    }
}
