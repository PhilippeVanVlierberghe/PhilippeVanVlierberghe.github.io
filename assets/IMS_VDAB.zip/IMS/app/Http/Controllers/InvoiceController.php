<?php

namespace App\Http\Controllers;

use LaravelDaily\Invoices\Invoice;
use LaravelDaily\Invoices\Classes\Buyer;
use LaravelDaily\Invoices\Classes\InvoiceItem;
use Carbon\Carbon;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ServiceItemController;
use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\Customer;
use App\Models\DocumentServiceItem;
use Illuminate\Routing\Controller;
use App\GlobalParam;
use ZipArchive;
use Illuminate\Pagination\LengthAwarePaginator;

class InvoiceController extends Controller
{
    public function createInvoice()
    {
        $customers = CustomerController::getCustomerRecords();
        $invoiceItems = ServiceItemController::getServiceItemRecords();
        $lastDocument_code_query = Document::orderby('created_at', 'desc')->pluck('document_code')->first();
        if ($lastDocument_code_query === null) {
            $lastDocument_code = date("Y") . '.' . 111;
        } else {
            $lastDocument_code = date("Y") . '.' . 1 + (int)(substr($lastDocument_code_query, 8, strlen($lastDocument_code_query)));
        }

        return view(
            'vendor.invoices.createInvoice',
            [
                'customers' => $customers,
                'invoiceItems' => $invoiceItems,
                'lastDocument_code' => $lastDocument_code
            ]
        );
    }

    public function getDocuments()
    {
        $documents = Document::orderby('id')->get();
        return view('vendor.invoices.table', ['documents' => $documents]);
    }

    public function getDocumentPaginatSortList($filterDocCode, $filterDocumentDate, $filterDocumentType): LengthAwarePaginator
    {
        switch (true) {
            case ($filterDocCode):
                $documents = Document::with('customer')
                    ->sortable()
                    ->where('documents.document_code', 'like', '%' . $filterDocCode . '%')
                    ->paginate(GlobalParam::$PAGINATIONNUMBER);
                break;

            case ($filterDocumentDate):
                $documents = Document::with('customer')
                    ->sortable()
                    ->where('documents.documentDate', 'like', '%' . $filterDocumentDate . '%')
                    ->paginate(GlobalParam::$PAGINATIONNUMBER);
                break;

            case ($filterDocumentType):
                $documents = Document::with('customer')
                    ->sortable()
                    ->where('documents.documentType', $filterDocumentType)
                    ->paginate(GlobalParam::$PAGINATIONNUMBER);
                break;

            default:
                $documents = Document::with('customer')
                    ->sortable()
                    ->paginate(GlobalParam::$PAGINATIONNUMBER);
        }
        return $documents;
    }
    public function getDocumentList($filterDocCode, $filterDocumentDate, $filterDocumentType)
    {
        switch (true) {
            case ($filterDocCode):
                $documents = Document::with('customer')
                    ->where('documents.document_code', 'like', '%' . $filterDocCode . '%')
                    ->get();
                break;

            case ($filterDocumentDate):
                $documents = Document::with('customer')
                    ->where('documents.documentDate', 'like', '%' . $filterDocumentDate . '%')
                    ->get();
                break;

            case ($filterDocumentType):
                $documents = Document::with('customer')
                    ->where('documents.documentType', $filterDocumentType)
                    ->get();
                break;

            default:
                $documents = Document::with('customer')
                    ->get();
        }
        return $documents;
    }

    public function indexDocumentsPaging(Request $request)
    {
        $filterDocCode = $request->query('filterDocCode');
        $filterDocumentDate = $request->query('filterDocumentDate');
        $filterDocumentType = $request->query('filterDocumentType');
        setcookie("filterDocCode", ($filterDocCode ?? 0), time() + GlobalParam::$ONEDAYSEC, "/"); // 86400 = 1 day
        setcookie("filterDocumentDate", ($filterDocumentDate ?? 0), time() + GlobalParam::$ONEDAYSEC, "/"); // 86400 = 1 day
        setcookie("filterDocumentType", ($filterDocumentType ?? 0), time() + GlobalParam::$ONEDAYSEC, "/"); // 86400 = 1 day

        return view('vendor.invoices.table')->with(
            [
                'documents' => $this->getDocumentPaginatSortList($filterDocCode, $filterDocumentDate, $filterDocumentType),
                'filterDocCode' => $filterDocCode,
                'filterDocumentDate' => $filterDocumentDate,
                'filterDocumentType' => $filterDocumentType
            ]
        );
    }

    public function showCreatedInvoice(Request $request)
    {
        $customer = $this->createCustomerObject(Customer::find((int)$request->customerId));
        $invoiceItemsArray = array();
        //Dit zijn de html table input elementen uit de form
        foreach ($request->invoiceItem_id as $key => $value) {
            if (isset($_POST["invoiceItem_add$key"])) {
                $invoiceItem = ([
                    'title' => $request->invoiceItem_title[$key],
                    'descriptions' => $request->invoiceItem_descriptions[$key],
                    'unitPriceSale' => $request->invoiceItem_unitPrice[$key],
                    'taxPercentageAsInt' => $request->invoiceItem_taxPercentageAsInt[$key],
                    'serviceItemAmount' => 1 //enkel voor de DB
                ]);
                array_push($invoiceItemsArray, $invoiceItem);
            }
        }

        if (count($invoiceItemsArray) < 1) {
            return redirect()->back()->withErrors("Gelieve diensten te kiezen voor de factuur.");
        }

        $request->validate(
            [
                'document_code' => 'required|unique:documents',
                'documentType' => 'required|min:2',
                'documentDate' => 'required',
                'notes' => 'nullable'
            ],
            [
                'document_code.unique' => 'Gelieve een unieke factuurnummer code te gebruiken.',
                'document_code.required' => 'Gelieve het factuurnummer in te vullen.',
            ]
        );

        $document = new Document([
            'customer_id' => $request->customerId,
            'document_code' => $request->input('document_code'),
            'documentType' => $request->input('documentType'),
            'documentDate' => $request->input('documentDate'),
            'notes' => $request->input('notes')
        ]);
        $document->save();
        $document = Document::latest()->first();
        $documentServiceItems = array();

        //convert html table inputs to DocumentServiceItem objects
        foreach ($invoiceItemsArray as $invoiceItem) {
            $documentServiceItem = new DocumentServiceItem([
                'document_id' => $document->id,
                'title' => $invoiceItem['title'],
                'descriptions' => $invoiceItem['descriptions'],
                'unitPriceSale' => $invoiceItem['unitPriceSale'],
                'taxPercentageAsInt' => $invoiceItem['taxPercentageAsInt'],
                'serviceItemAmount' => $invoiceItem['serviceItemAmount']
            ]);
            $documentServiceItem->save();
            array_push($documentServiceItems, $documentServiceItem);
        }

        /*create PDF*/
        $invoice = $this->createInvoiceObject($request, $customer);
        $this->addDocumentNotes($document, $invoice);
        $this->addInvoiceItems($documentServiceItems, $invoice);
        return $invoice->stream(); //render to PDF
    }

    public function getHistoricDocument(int $id)
    {
        $document = Document::find($id);
        $invoiceItems = $document->getDocumentServiceItem($id);
        $customer = $this->createCustomerObject(Customer::withTrashed()->find($document->customer_id));
        $invoice = $this->createInvoiceObject($document, $customer);
        $this->addDocumentNotes($document, $invoice);
        $this->addInvoiceItems($invoiceItems, $invoice);
        return $invoice->stream(); //render to PDF*/
    }

    private function createInvoiceObject($document, $customer)
    {
        $documentTypeString = ($document->documentType === "FA") ? "Factuur" : "Offerte";
        $invoice = Invoice::make()
            ->logo(public_path('vendor/invoices/logo.png'))
            ->name($documentTypeString)
            ->serialNumberFormat(substr($document->document_code, 0, 2) . '.' . substr($document->document_code, 3, strlen($document->document_code)))
            ->buyer($customer)
            ->date(Carbon::create($document->documentDate))
            ->dateFormat(GlobalParam::$DATEFORMATCODE)
            ->currencyCode(GlobalParam::$CURRENCYCODE)
            ->payUntilDays(GlobalParam::$D14);
        return $invoice;
    }

    private function addDocumentNotes(Document $document, Invoice $invoice)
    {
        if ($document->notes) {
            $invoice->notes(GlobalParam::$HTMLBREAKTAG . nl2br($document->notes));
        }
    }

    private function addInvoiceItems($invoiceItems, Invoice $invoice)
    {
        foreach ($invoiceItems as $item) {
            if ($item->descriptions) {
                $lijn = (new InvoiceItem())
                    ->title($item->title)
                    ->pricePerUnit($item->unitPriceSale)
                    ->descriptions(explode(GlobalParam::$NEWLINECODE, $item->descriptions))
                    ->tax_percentage_value($item->taxPercentageAsInt . GlobalParam::$PROCENTSIGN)
                    ->taxByPercent($item->taxPercentageAsInt);
            } else {
                $lijn = (new InvoiceItem())
                    ->title($item->title)
                    ->pricePerUnit($item->unitPriceSale)
                    ->tax_percentage_value($item->taxPercentageAsInt . GlobalParam::$PROCENTSIGN)
                    ->taxByPercent($item->taxPercentageAsInt);
            }
            $invoice->addItem($lijn);
        }
    }

    //customer = Buyer
    private function createCustomerObject($customerRecord)
    {
        if ($customerRecord->VATnumber) {
            $customer = new Buyer([
                'name' => $customerRecord->firstName . ' ' . $customerRecord->lastName,
                'custom_fields' => [
                    'ondernemingsnummer' => $customerRecord->VATnumber,
                    'address' => $customerRecord->address,
                    'zip' => $customerRecord->zip . ' ' . $customerRecord->residence,
                    'email' => $customerRecord->email
                ]
            ]);
        } else {
            $customer = new Buyer([
                'name' => $customerRecord->firstName . ' ' . $customerRecord->lastName,
                'custom_fields' => [
                    'address' => $customerRecord->address,
                    'zip' => $customerRecord->zip . ' ' . $customerRecord->residence,
                    'email' => $customerRecord->email
                ]
            ]);
        }
        return $customer;
    }

    public function expotToZip()
    {
        $documentSortList = $this->getDocumentList(
            $_COOKIE['filterDocCode'],
            $_COOKIE['filterDocumentDate'],
            $_COOKIE['filterDocumentType']
        );

        if (isset($documentSortList)) {
            $zip = new ZipArchive();
            $zip_name = "zip/IMS_folder.zip"; // Zip name
            /*
            https://www.php.net/manual/en/class.ziparchive.php
            ERROR OVERWRITE => It happens when the zip archive is empty.
            Your zip archive will not be saved on disk unless it has at least one file. 
            What's more, when ZipArchive::OVERWRITE is applied, if there exists a file with the same name, 
            it will be removed after ZipArchive::open() is called.
            So, don't forget to put at least one file to your zip archive.
            */
            if ($zip->open($zip_name,  ZipArchive::OVERWRITE) == FALSE) {
                dd("Error with zip folder: " . $zip_name);
            }

            foreach ($documentSortList as $file) {
                $pdf = $this->getHistoricDocument($file->id);
                //$zip->addFile($pdf,  $file->id);
                $zip->addFromString($file->document_code . ".pdf", $pdf);
            }

            $zip->close();

            if (file_exists($zip_name)) {
                header("Content-type: application/zip");
                header("Content-Disposition: attachment; filename=" . $zip_name);
                readfile($zip_name);
            }
        }
        return redirect()->back();
    }
}
