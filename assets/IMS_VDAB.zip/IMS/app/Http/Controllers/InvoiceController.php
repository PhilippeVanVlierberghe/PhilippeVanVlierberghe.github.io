<?php
namespace App\Http\Controllers;
use LaravelDaily\Invoices\Invoice;
use LaravelDaily\Invoices\Classes\Buyer;
use LaravelDaily\Invoices\Classes\InvoiceItem;
use Carbon\Carbon;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ServiceItemController;
use Illuminate\Http\Request;
use App\Models\Document;
use App\Models\Customer;
use App\Models\DocumentServiceItem;
use Illuminate\Routing\Controller;
use App\GlobalClass;
use App\Http\Requests\CreateInvoiceRequest;
use ZipArchive;
use LaravelDaily\Invoices\Contracts\PartyContract;


class InvoiceController extends Controller
{
    public function createInvoice()
    {
        $customers = CustomerController::getCustomerRecords();
        $invoiceItems = ServiceItemController::getServiceItemRecords();
        return view(
            'vendor.invoices.createInvoice',
            [
                'customers' => $customers,
                'invoiceItems' => $invoiceItems,
                // 'lastDocument_code' => $lastDocument_code
            ]
        );
    }

    public function indexDocumentsPaging(Request $request)
    {
        $filterDocCode = $request->query('filterDocCode');
        $filterDocumentDateFrom =  $request->query('filterDocumentDateFrom');
        $filterDocumentDateUntil =  $request->query('filterDocumentDateUntil');
        $filterDocumentType = $request->query('filterDocumentType');
        $request->session()->put('filterDocCode',$filterDocCode);
        $request->session()->put('filterDocumentType',$filterDocumentType);
        $request->session()->put('filterDocumentDateFrom',$filterDocumentDateFrom);
        $request->session()->put('filterDocumentDateUntil',$filterDocumentDateUntil);

        return view('vendor.invoices.table')->with(
            [
                'documents' => $this->filterDocumentList($filterDocCode, $filterDocumentType, $filterDocumentDateFrom, $filterDocumentDateUntil),
                'filterDocCode' => $filterDocCode,
                'filterDocumentType' => $filterDocumentType,
                'filterDocumentDateFrom' => $filterDocumentDateFrom,
                'filterDocumentDateUntil' => $filterDocumentDateUntil
            ]
        );
    }

    public function getDiffDays($d1, $d2): int
    {
        return (int)date_diff(
            date_create($d1),
            date_create($d2)
        )->format('%R%a');
    }

    public function getDueDateDays($documentDate, $documentDueDateDays): ?int
    {
        $dueDays = $this->getDiffDays($documentDate, $documentDueDateDays);
        return ($dueDays > 0) ? $dueDays :   GlobalClass::$D14;
    }

    public function showCreatedInvoice(CreateInvoiceRequest $request)
    {
        if (strpos($request->document_code, GlobalClass::$UNDEFINED)) {
            return redirect()->back()->withErrors(__('Create an invoice number'));
        }
        if ($request->documentDueDateDays <> null) {
            if ($this->getDiffDays($request->documentDate, $request->documentDueDateDays) < 0) {
                return redirect()->back()->withErrors(__('Select an expiry date'));
            }
        }
        $cTemp = Customer::find((int)$request->customerId);
        $customer = $this->createCustomerObject(
            $cTemp->firstName,
            $cTemp->lastName,
            $cTemp->company,
            $cTemp->VATnumber,
            $cTemp->address,
            $cTemp->residence,
            $cTemp->zip,
            $cTemp->email,
            $cTemp->phone
        );

        $invoiceItemsArray = array();
        //Dit zijn de html table input elementen uit de form
        foreach ($request->invoiceItem_id as $key => $value) {
            if (isset($request->invoiceItem_add[$key])) {
                $invoiceItem = ([
                    'title' => $request->invoiceItem_title[$key],
                    'descriptions' => $request->invoiceItem_descriptions[$key],
                    'unitPriceSale' => $request->invoiceItem_unitPrice[$key],
                    'taxPercentageAsInt' => $request->invoiceItem_taxPercentageAsInt[$key],
                    'serviceItemAmount' => 1 //enkel voor de DB
                ]);
                array_push($invoiceItemsArray, $invoiceItem);
            }
        }

        if (count($invoiceItemsArray) < 1) {
            return redirect()->back()->withErrors(__('Select a service'));
        }

        $document = new Document([
            'firstName' => $cTemp->firstName,
            'lastName' => $cTemp->lastName,
            'company' => $cTemp->company,
            'VATnumber' => $cTemp->VATnumber,
            'isCoContractor' =>($request->input('isMedecontractant'))?1:0,
            'address' => $cTemp->address,
            'residence' => $cTemp->residence,
            'zip' => $cTemp->zip,
            'email' => $cTemp->email,
            'phone' => $cTemp->phone,
            'document_code' => $request->input('document_code'),
            'documentType' => $request->input('documentType'),
            'documentDate' => $request->input('documentDate'),
            'documentDueDateDays' => $this->getDueDateDays(
                $request->input('documentDate'),
                $request->input('documentDueDateDays')
            ),
            'notes' => $request->input('notes')
        ]);
        $document->save();
        $document = Document::latest()->first();
        $documentServiceItems = array();

        //convert html table inputs to DocumentServiceItem objects
        foreach ($invoiceItemsArray as $invoiceItem) {
            $documentServiceItem = new DocumentServiceItem([
                'document_id' => $document->id,
                'title' => $invoiceItem['title'],
                'descriptions' => $invoiceItem['descriptions'],
                'unitPriceSale' => $invoiceItem['unitPriceSale'],
                'taxPercentageAsInt' => $invoiceItem['taxPercentageAsInt'],
                'serviceItemAmount' => $invoiceItem['serviceItemAmount']
            ]);
            $documentServiceItem->save();
            array_push($documentServiceItems, $documentServiceItem);
        }

        /*create PDF*/
        $invoice = $this->createInvoiceObject($document, $customer);
        $this->addDocumentNotes($document, $invoice);
        $this->addInvoiceItems($documentServiceItems, $invoice);
        return redirect('invoice/table?filterDocCode=' . $document->document_code);
    }

    public function previewInvoice(CreateInvoiceRequest $request)
    {        
        if (strpos($request->document_code, GlobalClass::$UNDEFINED)) {
            return redirect()->back()->withErrors(__('Create an invoice number'));
        }
        if ($request->documentDueDateDays <> null) {
            if ($this->getDiffDays($request->documentDate, $request->documentDueDateDays) < 0) {
                return redirect()->back()->withErrors(__('Select an expiry date'));
            }
        }
        $cTemp = Customer::find((int)$request->customerId);
        $customer = $this->createCustomerObject(
            $cTemp->firstName,
            $cTemp->lastName,
            $cTemp->company,
            $cTemp->VATnumber,
            $cTemp->address,
            $cTemp->residence,
            $cTemp->zip,
            $cTemp->email,
            $cTemp->phone
        );

        $invoiceItemsArray = array();
        //Dit zijn de html table input elementen uit de form
        foreach ($request->invoiceItem_id as $key => $value) {
            if (isset($request->invoiceItem_add[$key])) {
                $invoiceItem = ([
                    'title' => $request->invoiceItem_title[$key],
                    'descriptions' => $request->invoiceItem_descriptions[$key],
                    'unitPriceSale' => $request->invoiceItem_unitPrice[$key],
                    'taxPercentageAsInt' => $request->invoiceItem_taxPercentageAsInt[$key],
                    'serviceItemAmount' => 1 //enkel voor de DB
                ]);

                array_push($invoiceItemsArray, $invoiceItem);
            }
        }

        if (count($invoiceItemsArray) < 1) {
            return redirect()->back()->withErrors(__('Select a service'));
        }

        $document = new Document([
            'firstName' => $cTemp->firstName,
            'lastName' => $cTemp->lastName,
            'company' => $cTemp->company,
            'VATnumber' => $cTemp->VATnumber,
            'isCoContractor' =>$request->input('isMedecontractant'),
            'address' => $cTemp->address,
            'residence' => $cTemp->residence,
            'zip' => $cTemp->zip,
            'email' => $cTemp->email,
            'phone' => $cTemp->phone,
            'document_code' => $request->input('document_code'),
            'documentType' => $request->input('documentType'),
            'documentDate' => $request->input('documentDate'),
            'documentDueDateDays' => $this->getDueDateDays(
                $request->input('documentDate'),
                $request->input('documentDueDateDays')
            ),
            'notes' => $request->input('notes')
        ]);
        $documentServiceItems = array();

        //convert html table inputs to DocumentServiceItem objects
        foreach ($invoiceItemsArray as $invoiceItem) {
            $documentServiceItem = new DocumentServiceItem([
                'document_id' => $document->id,
                'title' => $invoiceItem['title'],
                'descriptions' => $invoiceItem['descriptions'],
                'unitPriceSale' => $invoiceItem['unitPriceSale'],
                'taxPercentageAsInt' => $invoiceItem['taxPercentageAsInt'],
                'serviceItemAmount' => $invoiceItem['serviceItemAmount']
            ]);
            array_push($documentServiceItems, $documentServiceItem);
        }

        /*create PDF*/
        $invoice = $this->createInvoiceObject($document, $customer);
        $invoice->setIsCoContractor($request->isMedecontractant);
        $this->addDocumentNotes($document, $invoice);
        $this->addInvoiceItems($documentServiceItems, $invoice);
        return $invoice->stream();
    }

    public function getHistoricDocument(int $id)
    {
        $document = Document::find($id);
        $invoiceItems = $document->getDocumentServiceItem($id);
        $customer = $this->createCustomerObject(
            $document->firstName,
            $document->lastName,
            $document->company,
            $document->VATnumber,
            $document->address,
            $document->residence,
            $document->zip,
            $document->email,
            $document->phone
        );
        $invoice = $this->createInvoiceObject($document, $customer, false);
        $invoice->setIsCoContractor($document->isCoContractor);
        $this->addDocumentNotes($document, $invoice);
        $this->addInvoiceItems($invoiceItems, $invoice);
        return $invoice->stream(); //render to PDF*/
    }

    private function createInvoiceObject($document, $customer)
    {

        $documentTypeString = ($document->documentType === "FA") ? "Factuur" : "Offerte";
        $invoice = Invoice::make()
            ->logo(public_path('vendor/invoices/logo.png'))
            ->name($documentTypeString)
            ->serialNumberFormat(substr($document->document_code, 0, 2) . '.' . substr($document->document_code, 3, strlen($document->document_code)))
            ->buyer($customer)
            ->date(Carbon::create($document->documentDate))
            ->dateFormat(GlobalClass::$DATEFORMATCODE)
            ->currencyCode(GlobalClass::$CURRENCYCODE)
            ->payUntilDays($document->documentDueDateDays);
        return $invoice;
    }

    private function addDocumentNotes(Document $document, Invoice $invoice)
    {
        if ($document->notes) {
            $invoice->notes(GlobalClass::$HTMLBREAKTAG . nl2br($document->notes));
        }
    }

    private function addInvoiceItems($invoiceItems, Invoice $invoice)
    {
        foreach ($invoiceItems as $item) {
            if ($item->descriptions) {
                $lijn = (new InvoiceItem())
                    ->title($item->title)
                    ->pricePerUnit($item->unitPriceSale)
                    ->descriptions(explode(GlobalClass::$NEWLINECODE, $item->descriptions))
                    ->tax_percentage_value($item->taxPercentageAsInt . GlobalClass::$PROCENTSIGN)
                    ->taxByPercent($item->taxPercentageAsInt);
            } else {
                $lijn = (new InvoiceItem())
                    ->title($item->title)
                    ->pricePerUnit($item->unitPriceSale)
                    ->tax_percentage_value($item->taxPercentageAsInt . GlobalClass::$PROCENTSIGN)
                    ->taxByPercent($item->taxPercentageAsInt);
            }
            $invoice->addItem($lijn);
        }
    }

    //customer = Buyer
    private function createCustomerObject(
        $firstName,
        $lastName,
        $company,
        $VATnumber,
        $address,
        $residence,
        $zip,
        $email,
        $phone
    ): PartyContract {
        if ($firstName) { //particulier
            $customer = new Buyer([
                'name' => $firstName . ' ' . $lastName,
                'custom_fields' => [
                    'address' => $address,
                    'zip' => $zip . ' ' . $residence,
                    'email' => $email
                ]
            ]);
        } else { //firma
            $customer = new Buyer([
                'name' => $company,
                'custom_fields' => [
                    'ondernemingsnummer' => $VATnumber,
                    'address' => $address,
                    'zip' => $zip . ' ' . $residence,
                    'email' => $email
                ]
            ]);
        }

        return $customer;
    }

    public function expotToZip()
    {
        $documentSortList = $this->getDocumentZipArchive(
            (session('filterDocCode') ?? ''),
            (session('filterDocumentType') ?? ''),
            (session('filterDocumentDateFrom') ?? ''),
            (session('filterDocumentDateUntil') ?? '')
        );

        if (isset($documentSortList)) {
            $zip = new ZipArchive();
            $zip_name = "zip/IMS_folder.zip"; // Zip name
            /*
            https://www.php.net/manual/en/class.ziparchive.php
            ERROR OVERWRITE => It happens when the zip archive is empty.
            */
            if (!$zip->open($zip_name,  ZipArchive::OVERWRITE)) {
                return redirect()->back()->withErrors(__('Error with zip folder').' '. $zip_name);
            }

            foreach ($documentSortList as $file) {
                $pdf = $this->getHistoricDocument($file->id);
                $zip->addFromString($file->document_code . ".pdf", $pdf);
            }

            $zip->close();

            if (file_exists($zip_name)) {
                header("Content-type: application/zip");
                header("Content-Disposition: attachment; filename=" . $zip_name);
                readfile($zip_name);
            }
        }
        return redirect()->back();
    }

    //Queries
    //-----------------------------------

    public function getDocumentZipArchive($filterDocCode, $filterDocumentType, $filterDocumentDateFrom, $filterDocumentDateUntil)
    {
        if ($filterDocumentDateFrom) {
            return Document::with('customer')
                ->sortable()
                ->where('documents.document_code', 'like', '%' . $filterDocCode  . '%')
                ->where('documents.documentType', 'like', '%' . $filterDocumentType . '%')
                ->whereBetween('documents.documentDate', [$filterDocumentDateFrom, $filterDocumentDateUntil])
                ->get();
        }
        return Document::with('customer')
            ->sortable()
            ->where('documents.document_code', 'like', '%' . $filterDocCode  . '%')
            ->where('documents.documentType', 'like', '%' . $filterDocumentType . '%')
            ->get();
    }

    public function filterDocumentList($filterDocCode, $filterDocumentType, $filterDocumentDateFrom, $filterDocumentDateUntil)
    {
        if ($filterDocumentDateFrom) {
            return Document::with('customer')
                ->sortable()
                ->where('documents.document_code', 'like', '%' . $filterDocCode  . '%')
                ->where('documents.documentType', 'like', '%' . $filterDocumentType . '%')
                ->whereBetween('documents.documentDate', [$filterDocumentDateFrom, $filterDocumentDateUntil])
                ->paginate(GlobalClass::$PAGINATIONNUMBER);
        }
        return Document::with('customer')
            ->sortable()
            ->where('documents.document_code', 'like', '%' . $filterDocCode  . '%')
            ->where('documents.documentType', 'like', '%' . $filterDocumentType . '%')
            ->paginate(GlobalClass::$PAGINATIONNUMBER);
    }
}
