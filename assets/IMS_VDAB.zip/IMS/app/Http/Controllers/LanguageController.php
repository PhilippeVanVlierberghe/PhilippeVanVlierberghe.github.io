<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class LanguageController extends Controller
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function setLanguage()
    {
        $lan =$_GET["lan"];
        session()->put('lan',$lan);
        if ($lan){
            APP::setLocale($lan);
            Session::put('applocale', $lan);
        }
        else{
            APP::setLocale(config('app.locale'));
        }
  
        return Redirect::back();
    }
}
