<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceItem;
use Illuminate\Routing\Controller;
use App\GlobalClass;
use App\Http\Requests\RegisterServiceCreateRequest;
use App\Http\Requests\RegisterServiceUpdateRequest;

class ServiceItemController extends Controller
{

    public function getServiceItems()
    {
        $serviceItems = ServiceItem::orderby('id')->get();
        return view('serviceItem.table', ['serviceItems' => $serviceItems]);
    }

    public function indexServiceItemsPaging(Request $request)
    {
        $filterDienst = $request->query('filterDienst');
        switch (true) {
            case ($filterDienst):
                $serviceItems = ServiceItem::Sortable()
                    ->where('service_items.title', 'like', '%' . $filterDienst . '%')
                    ->paginate(GlobalClass::$PAGINATIONNUMBER);
                break;
            default:
                $serviceItems = ServiceItem::Sortable()
                    ->paginate(GlobalClass::$PAGINATIONNUMBER);
        }
        return view('serviceItem.table')->with(
            [
                'serviceItems' => $serviceItems,
                'filterDienst' => $filterDienst
            ]
        );
    }

    public function getServiceItemsById(array $lijstIds)
    {
        $serviceItems = array();
        foreach ($lijstIds as $id) {
            $serviceItem = ServiceItem::find($id);
            array_push($serviceItems, $serviceItem);
        }
        return $serviceItems;
    }

    public static function getServiceItemRecords()
    {
        $serviceItems = ServiceItem::orderby('id')->get();
        return $serviceItems;
    }

    public function getCreateServiceItem()
    {
        return view('serviceItem.create');
    }

    public function postCreateServiceItem(RegisterServiceCreateRequest $request)
    {
        $serviceItem = new ServiceItem([
            'title' => $request->input('title'),
            'descriptions' => $request->input('descriptions'),
            'unitPrice' => str_replace(',', '.', $request->input('unitPrice')),
            'taxPercentageAsInt' => $request->input('taxPercentageAsInt')
        ]);
        $serviceItem->save();
        return redirect()->route('serviceItem.table')->with(
            'info',
            "De nieuwe dienst  '" . $request->input('title') . "' werdt toegevoegd."
        );
    }

    public function getDeleteServiceItem(int $id)
    {
        $serviceItem = ServiceItem::find($id);
        $title = $serviceItem->title;
        $serviceItem->delete();
        return redirect()->route('serviceItem.table')->with(
            'info',
            __('The service').' "'. $title . '" ' . __('Was removed')
        );
    }

    public function getEditServiceItem(int $id)
    {
        $serviceItem = ServiceItem::find($id);
        return view(
            'serviceItem.edit',
            [
                'serviceItem' => $serviceItem,
                'serviceItem_id' => $id
            ]
        );
    }

    public function getUpdateServiceItem(RegisterServiceUpdateRequest $request)
    {
        $serviceItem = ServiceItem::find($request->input('id'));
        $title = $serviceItem->title;
        $serviceItem->title = $request->input('title');
        $serviceItem->descriptions = $request->input('descriptions');
        $serviceItem->unitPrice = str_replace(',', '.', $request->input('unitPrice'));
        $serviceItem->taxPercentageAsInt = $request->input('taxPercentageAsInt');
        $serviceItem->save();
        return redirect()->route('serviceItem.table')->with(
            'info',
            __('The service').' "'. $title . '" ' . __('Was modified')
        );
    }
}
