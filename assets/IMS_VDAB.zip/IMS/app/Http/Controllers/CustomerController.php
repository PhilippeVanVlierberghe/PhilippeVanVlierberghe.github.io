<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\GlobalClass;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\RegisterCustomerCreateRequest;
use App\Http\Requests\RegisterCustomerUpdateRequest;

class CustomerController extends Controller
{
    public function indexCustomerPaging(Request $request)
    {
        $filterResidence = $request->query('filterResidence');
        $filterOndernemingsnummer = $request->query('filterOndernemingsnummer');
        $filterKlant = $request->query('filterKlant');

        //slecht één filter veld --> null velden en like werkt niet!
        switch (true) {
            case ($filterResidence):
                $customers = Customer::Sortable()
                    ->where('customers.residence', 'like', '%' . $filterResidence . '%')
                    ->paginate(GlobalClass::$PAGINATIONNUMBER);
                break;
            case ($filterOndernemingsnummer):
                $customers = Customer::Sortable()
                    ->where('customers.VATnumber', 'like', '%' . $filterOndernemingsnummer . '%')
                    ->paginate(GlobalClass::$PAGINATIONNUMBER);
                break;
            case ($filterKlant):
                $customers = Customer::Sortable()
                    ->whereRaw(DB::raw("CONCAT(customers.firstName,' ',customers.lastName)  like '%$filterKlant%'"))
                    ->orWhere('company', 'like', '%' . $filterKlant . '%')
                    ->paginate(GlobalClass::$PAGINATIONNUMBER);
                break;
            default:
                $customers = Customer::Sortable()->paginate(GlobalClass::$PAGINATIONNUMBER);
        }

        return view('customer.table')->with(
            [
                'customers' => $customers,
                'filterResidence' => $filterResidence,
                'filterOndernemingsnummer' => $filterOndernemingsnummer,
                'filterKlant' => $filterKlant
            ]
        );
    }

    public function postCreateCustomer(RegisterCustomerCreateRequest $request)
    {
        $customer = new Customer([
            'firstName' => $request->input('firstName'),
            'lastName' => $request->input('lastName'),
            'company' => $request->input('company'),
            'VATnumber' => $request->input('VATnumber'),
            'address' => $request->input('address'),
            'residence' => $request->input('residence'),
            'zip' => $request->input('zip'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone')
        ]);

        $customer->save();
        return redirect()->route('customer.table')->with(
            'info',
            $this->getStatusMessage($request->input('firstName'), $request->input('lastName'), $request->input('company'), 'toegevoegd')
        );
    }

    public function getCustomerEdit(int $id)
    {
        $customer = Customer::find($id);
        return view(
            'customer.edit',
            [
                'customer' => $customer,
                'customerId' => $id
            ]
        );
    }

    public function getCustomerDelete($id)
    {
        $customer = Customer::find($id);
        $customer->delete();
        return redirect()->route('customer.table')->with(
            'info',
            $this->getStatusMessage($customer->firstName, $customer->lastName, $customer->company, 'verwijderd')

        );
    }

    public function postCustomerUpdate(RegisterCustomerUpdateRequest $request)
    {
        $customer = Customer::find($request->input('id'));
        $customer->firstName  = $request->input('firstName');
        $customer->lastName = $request->input('lastName');
        $customer->company = $request->input('company');
        $customer->VATnumber = $request->input('VATnumber');
        $customer->address = $request->input('address');
        $customer->residence = $request->input('residence');
        $customer->zip = $request->input('zip');
        $customer->email = $request->input('email');
        $customer->phone = $request->input('phone');
        $customer->save();
        return redirect()->route('customer.table')->with(
            'info',
            $this->getStatusMessage($request->input('firstName'), $request->input('lastName'), $request->input('company'), 'aangepast')
        );
    }

    //Help methodes
    public static function getCustomerRecords()
    {
        $customers = Customer::orderby('firstName')->get();
        return $customers;
    }

    public function getCreateCustomer()
    {
        return view('customer.create');
    }

    public function getStatusMessage($firstName, $lastName, $company, $action): string
    {
        if ($firstName) {
            if ($action === 'aangepast') {
                return __('The customer') . ' "' . $firstName . ' ' . $lastName . '" ' . __('Was modified');
            } else {
                return __('The customer') . ' "' . $firstName . ' ' . $lastName . '" ' . __('Was removed');
            }
        } else {
            if ($action === 'aangepast') {
                return 'De firma "' . $company . '" ' . __('Was modified');
            } else {
                return __('The customer') . ' "' . $firstName . ' ' . $lastName . '" ' . __('Was removed');
            }
        }
    }
}
