<?php

namespace App\Http\Livewire;

use Livewire\Component;

class CustomerRegistrationUpdate extends Component
{
    public $customer;
    public $firstName;
    public $lastName;
    public $company;
    public $VATnumber;
    public $fliedCheck1 = false;
    public $fliedCheck2 = false;
    public $firstTimeGate = true;

    public function render()
    {
        if($this->firstTimeGate){
            $this->firstName = $this->customer->firstName ?? null;
            $this->lastName = $this->customer->lastName ?? null;
            $this->company = $this->customer->company ?? null;
            $this->VATnumber = $this->customer->VATnumber ?? null;
            $this->firstTimeGate = false;
        }        

        $this->fliedCheck1 = false;
        $this->fliedCheck2 = false;

        if (!empty($this->firstName) || !empty($this->lastName)) {
            $this->fliedCheck2 = !$this->fliedCheck2;
        }
        if (!empty($this->company) || !empty($this->VATnumber)) {
            $this->fliedCheck1 = !$this->fliedCheck1;
        }
        return view('livewire.customer-registration-update');
    }
}
