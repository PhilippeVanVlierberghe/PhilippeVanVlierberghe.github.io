<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Document;
use App\GlobalClass;

class DocumentNumber extends Component
{
    public $lastDocument_code;
    public $documentType;
    public $documentDate;
    public $strDocumentNr;
    public $customers;

    public function render()
    {
        $this->strDocumentNr = "Code";        
        (is_null($this->documentType) || $this->documentType === '') ? $code = GlobalClass::$UNDEFINED : $code = $this->documentType;
        (is_null($this->documentDate) || $this->documentDate === '') ? $year = GlobalClass::$UNDEFINED  : $year = substr($this->documentDate, 0, 4);
        $lastDocument_code_query = Document::where('documentType', $code)->orderby('created_at', 'desc')->pluck('document_code')->first();
        if (is_null($lastDocument_code_query)) {
            $this->lastDocument_code =  $code . '.' . $year . '.' . str_pad(GlobalClass::$DOCSTARTNR,3,'0', STR_PAD_LEFT);
        } else {
            $this->lastDocument_code =  $code . '.' . $year . '.' . str_pad((1 + (int)(substr($lastDocument_code_query, 8, strlen($lastDocument_code_query)))),3,'0', STR_PAD_LEFT);
        }
        return view('livewire.document-number');
    }
}
