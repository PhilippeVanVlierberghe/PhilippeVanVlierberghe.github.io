<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
class CheckRegistration
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $rules =([
            "name" => ["required", 'min:2'],
            "email" => ['required', 'email','unique:users'],
            "password" => ['required', 'min:8'],
            "password_confirmation" => ['required','same:password','min:8']
        ]);

        $validator= Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors([
                    "name" => "Gelieve 8 tekens te gebruiken aub.",
                    "email" => "Wij hebben al een acount met dit emailadres.",
                    "password" => "Gelieve twee keer hetzelfde wachtwoord te gebruiken aub."
                ]);
        }

        return $next($request);
    }
}
