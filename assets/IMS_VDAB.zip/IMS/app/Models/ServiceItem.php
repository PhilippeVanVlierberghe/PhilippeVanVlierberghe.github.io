<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;


class ServiceItem extends Model
{
    use HasFactory;
    use Sortable;
    
    protected $table = "service_items";

    protected $fillable = [
        'title',
        'descriptions',
        'unitPrice',
        'taxPercentageAsInt'
    ];

    public $sortable= [
        'title',
        'descriptions',
        'unitPrice',
        'taxPercentageAsInt'
    ];

    public function documents(){
        return $this->belongsToMany(Document::class,'document_service_items');
    }
}
