<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DocumentServiceItem extends Model
{
    use HasFactory;
    protected $table ="document_service_items";
    
    protected $fillable = [
        'document_id',
        'title',
        'descriptions',
        'unitPriceSale',
        'taxPercentageAsInt',
        'serviceItemAmount'
    ];
}
