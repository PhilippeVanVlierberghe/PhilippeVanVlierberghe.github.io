<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Document extends Model
{
    //trails
    use HasFactory;
    use Sortable;

    protected $table ="documents";

    protected $fillable = [
        'id',
        'customer_id',
        'document_code',
        'documentType',
        'documentDate',
        'notes'
    ];

    protected $sortable = [
        'id',
        'document_code',
        'documentType',
        'documentDate',
    ];

    public function getDocumentServiceItem(int $id){
        $documentServiceItems = DocumentServiceItem::where('document_id','=',$id)->get();
        return $documentServiceItems;
    }

    //withTrashed() to include soft deleted customers
    public function customer(){
        return $this->belongsTo(Customer::class)->withTrashed();
    }
}
