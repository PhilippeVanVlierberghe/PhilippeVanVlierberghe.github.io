<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;
use App\GlobalClass;
class Document extends Model
{
    //trails
    use HasFactory;
    use Sortable;

    protected $table = "documents";

    protected $fillable = [
        'id',
        'firstName',
        'lastName',
        'company',
        'VATnumber',
        'isCoContractor',
        'address',
        'residence',
        'zip',
        'email',
        'phone',
        'document_code',
        'documentType',
        'documentDate',
        'documentDueDateDays',
        'notes'
    ];

    protected $sortable = [
        'id',
        'document_code',
        'documentType',
        'documentDate',
        'firstName'
    ];

    public function getDocumentServiceItem(int $id)
    {
        $documentServiceItems = DocumentServiceItem::where('document_id', '=', $id)->get();
        return $documentServiceItems;
    }

    //withTrashed() to include soft deleted customers
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function getCustomerName(){
        return GlobalClass::getCustomerName($this->firstName,$this->lastName,$this->company);
    }
}
