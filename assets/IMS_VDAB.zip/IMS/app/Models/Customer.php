<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Kyslik\ColumnSortable\Sortable;

class Customer extends Model
{
    //traits 
    use HasFactory;
    use SoftDeletes;
    use Sortable;
       
    public $table = 'customers';

    public $fillable = [
        'firstName',
        'lastName',
        'VATnumber',
        'address',
        'residence',
        'zip',
        'email',
        'phone'
    ];

    public $sortable =[
        'id',
        'firstName',
        'lastName',
        'VATnumber',
        'address',
        'residence',
        'zip',
        'email',
        'phone'
    ];

    protected $hidden = [
        'remember_token'
    ];

    protected $dates = [ 'deleted_at' ];

    public function getFullName(){
        return $this->firstName.' '.$this->lastName;
    }

    public function documents(){
        return $this->hasMany(Document::class);
    }
}
