<?php

namespace App\Models;

use App\GlobalClass;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Customer extends Model
{
    //traits 
    use HasFactory;
    use Sortable;
       
    public $table = 'customers';

    public $fillable = [
        'firstName',
        'lastName',
        'company',
        'VATnumber',
        'address',
        'residence',
        'zip',
        'email',
        'phone'
    ];

    public $sortable =[
        'id',
        'firstName',
        'lastName',
        'company',
        'VATnumber',
        'address',
        'residence',
        'zip',
        'email',
        'phone'
    ];

    protected $hidden = [
        'remember_token'
    ];

    public function getCustomerName(){
        return GlobalClass::getCustomerName($this->firstName,$this->lastName,$this->company);
    }

    public function documents(){
        return $this->hasMany(Document::class);
    }
}
