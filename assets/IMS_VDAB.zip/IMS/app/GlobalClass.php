<?php

namespace App;

class GlobalClass
{
    public static INT $PAGINATIONNUMBER = 5;
    public static Int $D14 = 14;
    public static String $NEWLINECODE = "\r\n";
    public static String $PROCENTSIGN = "%";
    public static String $HTMLBREAKTAG = "<br />";
    public static String $DATEFORMATCODE = "d/m/Y";
    public static String $CURRENCYCODE = "EUR";
    public static Int $ONEDAYSEC = 86400;
    public static String $UNDEFINED= "?"; 
    public static Int $DOCSTARTNR = 266;

    public static function getCustomerName($firstName,$lastName,$company){
        return (!$firstName)?$company:$firstName.' '.$lastName;
    }
}
