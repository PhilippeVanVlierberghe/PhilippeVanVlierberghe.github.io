<?php

namespace Database\Seeders;

use App\Models\Customer;
use App\Models\ServiceItem;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ServiceItemSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */

    public function run()
    {
        $service1 = new ServiceItem([
            "title" => "Uit te voeren werken",
            "descriptions" => "– Het terugsnoeien van een eik.\r\n– Het verwijderen van overhangende takken.\r\n– Het verwijderen van droog hout.\r\n– Het snoeien van sparren.\r\n– Het verhakselen van takkenhout.",
            "unitPrice" => 1400.00,
            "taxPercentageAsInt" => 21
        ]);
        $service1->save();

        $service2 = new ServiceItem([
            "title" => "Huur van de hoogtewerker",
            "descriptions" => null,
            "unitPrice" => 250.00,
            "taxPercentageAsInt" => 21
        ]);
        $service2->save();

        $service3 = new ServiceItem([
            "title" => "Bloemenperk aanleggen",
            "descriptions" => null,
            "unitPrice" => 50.00,
            "taxPercentageAsInt" => 6        ]);
        $service3->save();

        $service4 = new ServiceItem([
            "title" => "Het zaaien van gras",
            "descriptions" => "- Gazonzaad schaduwgazon 1 kg.\r\n- 50 m²",
            "unitPrice" => 31.05,
            "taxPercentageAsInt" => 21
        ]);
        $service4->save();

        $service5 = new ServiceItem([
            "title" => "Verwerken van hout tot brandhout",
            "descriptions" => null,
            "unitPrice" => 20,
            "taxPercentageAsInt" => 6
        ]);
        $service5->save();
    }
}
