<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */


    public function run()
    {
        $user1 = new User([
            "name" => "Philippe Van Vlierberghe",
            "email" => "philippe.vv@outlook.com",
            "email_verified_at" =>null,
            "password" => '$2y$10$bTM5djb90ZrOJERwgbrPPeN34YZmzVEIadgvmyYywx9q84jTEnV/i',
            "remember_token" => "null"
        ]);
        $user1->save();
    }
}
