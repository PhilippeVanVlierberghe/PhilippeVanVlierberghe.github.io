<?php

namespace Database\Factories;

use App\Models\Customer;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Customers>
 */
class CustomerFactory extends Factory
{
    protected $model = Customer::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    // "VATnumber" =>null,
    public function definition()
    {
        return [
            'firstName' => $this->faker->firstName(),
            'lastName'=> $this->faker->lastName(),
            'VATnumber' => $this->faker->randomElement(
                [
                    $this->faker->numerify('####.###.###'),
                    null
                ]
            ), 
            'address'=> $this->faker->address(),
            'residence'=>$this->faker->randomElement(
                [
                    "Tremelo",
                    "Baal",
                    "Langdorp",
                    "Werchter",
                    "Haacht",
                    "Tildonk",
                    "Aarschot",
                    "Leuven",
                    "Rotselaar",
                    "Holsbeek",
                    "Hulshout",
                    "Brussel"]
            ),
            'zip' =>$this->faker->numberBetween(1000,6000),
            'email'=> $this->faker->safeEmail(),
            "phone" => $this->faker->phoneNumber()
        ];
    }
}
