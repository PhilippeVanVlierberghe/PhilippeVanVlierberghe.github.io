
function docChange() {
    let docTypeCodeElement = document.getElementById('document_code');
    let docType = document.getElementById('documentType').value;
    let docTypeCode = docTypeCodeElement.value.replace("OF.","").replace("FA.","");
    let result = docTypeCode.value = docType + '.' + docTypeCode;
    docTypeCodeElement.value = result;
}
