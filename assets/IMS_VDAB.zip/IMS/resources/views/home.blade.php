@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Admin message</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if (!Auth::check())
                    <p>
                        {{ 'Meldt u aan of maak een gebruikersaccount aan om dit programma te gebruiken.' }}
                    </p>
                    <br>
                @else
                    <p>
                        {{ 'Bedankt dat u ons uw bedrijf toevertrouwd.' }}
                    </p>
                @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
