@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="{{ route('serviceItem.update') }}" method="post">
                    <div class="form-group">
                        <label for="title">Dienst</label>
                        <input type="text" class="form-control" id="title" name="title" value="{{ $serviceItem->title }}">
                        @if ($errors->has('title'))
                            <span class="text-danger">{{ $errors->first('title') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="descriptions">Toelichting</label>
                        <textarea id="descriptions" class="form-control" name="descriptions"
                            rows="4">{{$serviceItem->descriptions }}</textarea>
                        @if ($errors->has('descriptions'))
                            <span class="text-danger">{{ $errors->first('descriptions') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="unitPrice">Prijs</label>
                        <input type="text" class="form-control" id="unitPrice" name="unitPrice"
                            value="{{ $serviceItem->unitPrice }}">
                        @if ($errors->has('unitPrice'))
                            <span class="text-danger">{{ $errors->first('unitPrice') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="taxPercentageAsInt">BTW %</label>
                        <input type="text" class="form-control" id="taxPercentageAsInt" name="taxPercentageAsInt"
                            value="{{ $serviceItem->taxPercentageAsInt }}">
                        @if ($errors->has('taxPercentageAsInt'))
                            <span class="text-danger">{{ $errors->first('taxPercentageAsInt') }}</span>
                        @endif
                    </div>
                    {{ csrf_field() }}
                    <input type="hidden" name="id" value="{{ $serviceItem_id }}">

                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection
