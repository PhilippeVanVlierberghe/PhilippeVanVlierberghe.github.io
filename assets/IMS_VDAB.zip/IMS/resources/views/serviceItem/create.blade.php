@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="{{ route('serviceItem.create') }}" method="post">
                    <div class="form-group">
                        <label for="title">{{__('Service')}}</label>
                        <input type="text" class="form-control" id="title" name="title">
                        @if ($errors->has('title'))
                            <span class="text-danger">{{ $errors->first('title') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="descriptions">{{__('Explanation')}}</label>
                        <textarea id="descriptions" class="form-control" name="descriptions" rows="4"></textarea>
                        @if ($errors->has('descriptions'))
                            <span class="text-danger">{{ $errors->first('descriptions') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="unitPrice">{{__('Price')}}</label>
                        <input type="text" class="form-control" id="unitPrice" name="unitPrice">
                        @if ($errors->has('unitPrice'))
                            <span class="text-danger">{{ $errors->first('unitPrice') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="taxPercentageAsInt">{{__('VAT')}} %</label>
                        <input type="text" class="form-control" id="taxPercentageAsInt" name="taxPercentageAsInt">
                        @if ($errors->has('taxPercentageAsInt'))
                            <span class="text-danger">{{ $errors->first('taxPercentageAsInt') }}</span>
                        @endif
                    </div>
                    {{ csrf_field() }}
                    <br>
                    <button type="submit" class="btn btn-primary">{{__('Submit')}}</button>
                </form>
            </div>
        </div>
    </div>
@endsection
