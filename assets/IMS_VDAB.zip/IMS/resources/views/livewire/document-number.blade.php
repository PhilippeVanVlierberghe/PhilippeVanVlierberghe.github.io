<div class="row form-group-container">
    <div class="col-sm">
        <div class="form-group">
            <label for="documentType">{{ __('Document type') }}:</label>
            <br>
            <select wire:model="documentType" name="documentType" id="documentType" required>
                <option value="">{{ __('Choose an option') }}</option>
                <option value="FA">{{ __('Invoice') }}</option>
                <option value="OF">{{ __('Quotation') }}</option>
            </select>
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="documentDate">{{ __('Date') }}:</label>
            <br>
            <input wire:model="documentDate" type="date" id="documentDate" name="documentDate"
                value="{{ date('Y-m-d') }}" required>
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="documentDueDateDays">{{ __('Expiry date') }}:</label>
            <br>
            <input type="date" id="documentDueDateDays" name="documentDueDateDays">
        </div>
    </div>
    <div class="col-sm">
        <div class="form-group">
            <label for="document_code">{{ $strDocumentNr }}:</label>
            <br>
            <input type="text" minlength="11" name="document_code" id="document_code"
                value="{{ $lastDocument_code }}" readonly>
        </div>

    </div>

    <div class="col-sm">
        <div class="form-group">
            <label for="customerId">{{ __('Customer') }}:</label>
            <br>
            <select name="customerId" id="customerId">
                @foreach ($customers as $customer)
                    <option value="{{ $customer->id }}">
                        {{ $customer->getCustomerName() }}
                    </option>
                @endforeach
            </select>
        </div>
    </div>
    <br>
    <div class="col-sm">
        <div class="form-group">
            <label for="isMedecontractant">{{ __('Is a co-contractor') }}:</label>
            <br>
            <input type="checkbox" id="isMedecontractant" name="isMedecontractant">
        </div>
    </div>
</div>
