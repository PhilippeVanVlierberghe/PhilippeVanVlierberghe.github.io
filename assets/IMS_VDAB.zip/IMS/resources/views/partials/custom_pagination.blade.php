<ul class="pagination nav">

    @foreach ($elements as $element)

        @if (is_array($element))
            @foreach ($element as $page => $url)
                @if ($page == $paginator->currentPage())
                    <li class="active nav-item col-ms"><span>{{ $page }}</span></li>
                @else
                    <li class="nav-item col-ms"><a href="{{ $url }}">{{ $page }}</a></li>
                @endif
            @endforeach
        @endif
    @endforeach

    
</ul>