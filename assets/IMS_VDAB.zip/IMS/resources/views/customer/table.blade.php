@extends('layouts.master')

@section('content')
    <div class="container">
        @if (Session::has('info'))
            <div class="rowExtra">
                <div class="col-md-12">
                    <p class="alert alert-info">{{ Session::get('info') }}</p>
                </div>
            </div>
        @endif
        <p>
            <a class="btn btn-primary" href="{{ route('customer.create') }}">{{ __('Create a new customer') }}</a>
        </p>
        <div class="tableContainer">
            <div class="tableFilter">
                <div class="container">
                    <div class="row">
                        {{-- <div class="col">
                        <form class="form-inline" method="GET">
                            <div class="form-group">
                                <label for="filterDocumentType" class="col-form-label">Document type:</label>
                                <br>
                                <select name="filterDocumentType" id="filterDocumentType" onchange="this.form.submit()">
                                    <option value="" disabled selected>Kies een documenttype...</option>
                                    <option value="Factuur">Factuur</option>
                                    <option value="Offerte">Offerte</option>
                                </select>
                            </div>
                        </form>
                    </div> --}}
                        <div class="col-sm">
                            <form class="form-inline" method="GET">
                                <div class="form-group">
                                    <label for="filterKlant" class="col-form-label">{{ __('Search by customer') }}:</label>
                                    <input type="text" class="form-control" id="filterKlant" name="filterKlant"
                                        placeholder="{{ trans('Customer') . '...' }}" value="{{ $filterKlant }}">
                                </div>
                            </form>
                        </div>
                        <div class="col-sm">
                            <form class="form-inline" method="GET">
                                <div class="form-group">
                                    <label for="filterOndernemingsnummer"
                                        class="col-form-label">{{ __('Company number') }}:</label>
                                    <input type="text" class="form-control" id="filterOndernemingsnummer"
                                        name="filterOndernemingsnummer" placeholder="{{ trans('Company number') . '...' }}"
                                        value="{{ $filterOndernemingsnummer }}">
                                </div>
                            </form>
                        </div>
                        <div class="col-sm">
                            <form class="form-inline" method="GET">
                                <div class="form-group">
                                    <label for="filterResidence"
                                        class="col-form-label">{{ __('Search by residence') }}:</label>
                                    <input type="text" class="form-control" id="filterResidence" name="filterResidence"
                                        placeholder="{{ trans('Residence') . '...' }}" value="{{ $filterResidence }}">
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
            </div>
            <br>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">@sortablelink('id', '#')</th>
                            <th scope="col">@sortablelink('firstName', trans('Customer'))</th>
                            <th scope='col'>@sortablelink('VATnumber', trans('Company number'))</th>
                            <th scope="col">@sortablelink('address', trans('Address'))</th>
                            <th scope="col">@sortablelink('residence', trans('Residence'))</th>
                            <th scope="col">@sortablelink('zip', trans('Zip code'))</th>
                            <th scope="col">@sortablelink('email', trans('Email'))</th>
                            <th scope="col">@sortablelink('phone', trans('Phone'))</th>
                            <th><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path
                                        d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                    <path fill-rule="evenodd"
                                        d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                </svg></th>
                            <th><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-trash" viewBox="0 0 16 16">
                                    <path
                                        d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                    <path fill-rule="evenodd"
                                        d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                                </svg></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($customers as $customer)
                            <tr>
                                <th scope="row">{{ $customer->id }}</th>
                                <td>{{ $customer->getCustomerName() }}</td>
                                <td>{{ $customer->VATnumber }}</td>
                                <td>{{ $customer->address }}</td>
                                <td>{{ $customer->residence }}</td>
                                <td>{{ $customer->zip }}</td>
                                <td>{{ $customer->email }}</td>
                                <td>{{ $customer->phone }}</td>
                                <td><a
                                        href="{{ route('customer.edit', ['id' => $customer->id]) }}">{{ __('Edit') }}</a>
                                </td>
                                <td><a
                                        href="{{ route('customer.delete', ['id' => $customer->id]) }}">{{ __('Delete') }}</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="paginationContainer">
                <div>{{ $customers->appends($_GET)->links('partials.custom_pagination') }}</div>
            </div>
            {{-- TODO --}}
            {{-- <p>U ziet {{ $customers->count() }} van de {{ $customers->total() }} klant(en).</p> --}}
        </div>
    </div>
@endsection
