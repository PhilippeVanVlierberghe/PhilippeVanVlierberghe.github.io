@extends('layouts.master')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form action="{{ route('customer.create') }}" method="post">
                    <div class="form-group">
                        <label for="firstName">Voornaam</label>
                        <input type="text" class="form-control" id="firstName" name="firstName">
                        @if ($errors->has('firstName'))
                            <span class="text-danger">{{ $errors->first('firstName')}}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="lastName">Familienaam</label>
                        <input type="text" class="form-control" id="lastName" name="lastName">
                        @if ($errors->has('lastName'))
                            <span class="text-danger">{{ $errors->first('lastName') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="VATnumber">ondernemingsnummer</label>
                        <input type="text" class="form-control" id="VATnumber" name="VATnumber">
                        @if ($errors->has('VATnumber'))
                            <span class="text-danger">{{ $errors->first('VATnumber') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="address">Adres</label>
                        <input type="text" class="form-control" id="address" name="address">
                        @if ($errors->has('address'))
                            <span class="text-danger">{{ $errors->first('address') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="zip">Postcode</label>
                        <input type="text" class="form-control" id="zip" name="zip">
                        @if ($errors->has('zip'))
                            <span class="text-danger">{{ $errors->first('zip') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="residence">Woonplaats</label>
                        <input type="text" class="form-control" id="residence" name="residence">
                        @if ($errors->has('residence'))
                            <span class="text-danger">{{ $errors->first('residence') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" id="email" name="email">
                        @if ($errors->has('email'))
                            <span class="text-danger">{{ $errors->first('email') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="phone">Telefoon</label>
                        <input type="text" class="form-control" id="phone" name="phone">
                        @if ($errors->has('phone'))
                            <span class="text-danger">{{ $errors->first('phone') }}</span>
                        @endif
                    </div>
                    {{ csrf_field() }}
                    <br>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>
@endsection
