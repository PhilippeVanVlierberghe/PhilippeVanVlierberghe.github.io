@extends('layouts.master')

@section('content')
    <div class="container">
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Assumenda commodi illum nobis nostrum numquam officiis
            possimus provident rem repellat sint? Dicta eligendi eum hic, labore nisi non quidem quos voluptates.
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa debitis magni modi nihil numquam odit pariatur
            recusandae repellendus sint voluptates. Blanditiis expedita minus nostrum numquam placeat porro praesentium quae
            soluta!</p>
            @for ($i = 65; $i < 77; $i++)
                <a href="{{ URL::to('img/img'.chr($i).'.jpg') }}" target="_blank">
                <img class="aboutImg" src="{{ URL::to('img/img'.chr($i).'.jpg') }}" alt="test">
                </a>
            @endfor
    </div>
@endsection
