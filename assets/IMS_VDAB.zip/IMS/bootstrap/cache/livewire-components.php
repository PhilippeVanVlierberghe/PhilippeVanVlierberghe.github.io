<?php return array (
  'customer-registration-create' => 'App\\Http\\Livewire\\CustomerRegistrationCreate',
  'customer-registration-update' => 'App\\Http\\Livewire\\CustomerRegistrationUpdate',
  'document-number' => 'App\\Http\\Livewire\\DocumentNumber',
);