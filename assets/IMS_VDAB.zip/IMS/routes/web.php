<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ServiceItemController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Middleware\CheckIsUser;
use App\Http\Middleware\CheckRegistration;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', function () {
    return view('home');
})->name('home');

Route::get('/home', function () {
    return view('home');
})->name('home');


Route::get('about', function () {
    return view('other.about');
})->name('other.about');

//Invoice
Route::group(['prefix' =>"invoice", 'middleware' =>['auth']],function(){
    Route::get('/', [InvoiceController::class, 'show'])->name('vendor.invoices.templates.default.blade.php');
    Route::get('create', [InvoiceController::class, 'createInvoice'])->name('invoice.create');
    Route::post('create', [InvoiceController::class, 'showCreatedInvoice'])->name('invoice.create');
    Route::get('table',[InvoiceController::class, 'indexDocumentsPaging'])->name('invoice.table');
    Route::get('/',[InvoiceController::class, 'expotToZip'])->name('invoice.zip');
    Route::get('doc/{id}',[InvoiceController::class, 'getHistoricDocument'])->name('invoice.document');
});

//customers
Route::group(['prefix' =>"customer", 'middleware' =>['auth']],function(){
    Route::get('table', [CustomerController::class, 'indexCustomerPaging'])->name('customer.table');
    Route::get('create', [CustomerController::class, 'getCreateCustomer'])->name('customer.create');
    Route::post('create', [CustomerController::class, 'postCreateCustomer'])->name('customer.create');
    Route::get('delete/{id}', [CustomerController::class, 'getCustomerDelete'])->name('customer.delete');
    Route::get('edit/{id}', [CustomerController::class, 'getCustomerEdit'])->name('customer.edit');
    Route::post('update', [CustomerController::class, 'postCustomerUpdate'])->name('customer.update');
});

//Services
Route::group(['prefix' =>"serviceItem", 'middleware' =>['auth']],function(){
    Route::get('table', [ServiceItemController::class, 'indexServiceItemsPaging'])->name('serviceItem.table');
    Route::get('create', [ServiceItemController::class, 'getCreateServiceItem'])->name('serviceItem.create');
    Route::post('create', [ServiceItemController::class, 'postCreateServiceItem'])->name('serviceItem.create');
    Route::get('delete/{id}', [ServiceItemController::class, 'getDeleteServiceItem'])->name('serviceItem.delete');
    Route::get('edit/{id}', [ServiceItemController::class, 'getEditServiceItem'])->name('serviceItem.edit');
    Route::post('update', [ServiceItemController::class, 'getUpdateServiceItem'])->name('serviceItem.update');
});

Auth::routes();
// Authentication Routes...
Route::get('login', [LoginController::class,'showLoginForm'])->name('login');
Route::post('login', [LoginController::class,'login'])->middleware(CheckIsUser::class);;
Route::post('logout', [LoginController::class,'logout'])->name('logout');

// Registration Routes...
Route::get('register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('register', [RegisterController::class, 'register'])->middleware(CheckRegistration::class)->name('register');

// Password Reset Routes...
// Route::get('password/reset', [LoginController::class,'showLinkRequestForm'])->name('password.request');
// Route::post('password/email', [LoginController::class,'sendResetLinkEmail'])->name('password.email');
// Route::get('password/reset/{token}', [LoginController::class,'showResetForm'])->name('password.reset');
// Route::post('password/reset', [LoginController::class,'reset'])->name('password.update');

// // Confirm Password (added in v6.2)
// Route::get('password/confirm', [LoginController::class,'showConfirmForm'])->name('password.confirm');
// Route::post('password/confirm', [LoginController::class,'confirm']);

// // Email Verification Routes...
// Route::get('email/verify', [LoginController::class,'VerificationController@show'])->name('verification.notice');
// Route::get('email/verify/{id}/{hash}', [LoginController::class,'verify'])->name('verification.verify'); // v6.x
// /* Route::get('email/verify/{id}', [LoginController::class,'verify'])->name('verification.verify'); // v5.x */
// Route::get('email/resend', [LoginController::class,'resend'])->name('verification.resend');