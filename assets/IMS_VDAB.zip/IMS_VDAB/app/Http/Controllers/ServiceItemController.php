<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServiceItem;
use Illuminate\Routing\Controller;

class ServiceItemController extends Controller
{
    public function getServiceItems()
    {
        $serviceItems = ServiceItem::orderby('id')->get();
        return view('serviceItem.table', ['serviceItems' => $serviceItems]);
    }

    public function indexServiceItemsPaging(Request $request)
    {        
        $filterDienst = $request->query('filterDienst');
        switch (true) {
            case ($filterDienst):
                $serviceItems = ServiceItem::Sortable()
                    ->where('service_items.title', 'like', '%' . $filterDienst . '%')
                    ->paginate(3);
                break;
            default:
                $serviceItems = ServiceItem::Sortable()->paginate(3);
        }
        return view('serviceItem.table')->with(
            [
                'serviceItems' => $serviceItems,
                'filterDienst' => $filterDienst
            ]);
    }

    public function getServiceItemsById(array $lijstIds)
    {
        $serviceItems = array();
        foreach ($lijstIds as $id) {
            $serviceItem = ServiceItem::find($id);
            array_push($serviceItems, $serviceItem);
        }
        return $serviceItems;
    }

    public function getServiceItemRecords()
    {
        $serviceItems = ServiceItem::orderby('id')->get();
        return $serviceItems;
    }

    public function getCreateServiceItem()
    {
        return view('serviceItem.create');
    }

    public function postCreateServiceItem(Request $request)
    {
        $request->validate(
            [
                'title' => 'required',
                'descriptions' => 'nullable',
                'unitPrice' => 'required',
                'taxPercentageAsInt' => 'required|integer'
            ],
            [
                'title.required' => 'Gelieve een dienst titel in te vullen.',
                'unitPrice.required' => 'Gelieve een prijs in te vullen.',
                'unitPrice.numeric' => 'Gelieve een getal in tevullen voor de prijs.',
                'taxPercentageAsInt.required' => 'Gelieve een geheel getal in tevullen voor het BTW %.'
            ]
        );
        $serviceItem = new ServiceItem([
            'title' => $request->input('title'),
            'descriptions' => $request->input('descriptions'),
            'unitPrice' => $request->input('unitPrice'),
            'taxPercentageAsInt' => $request->input('taxPercentageAsInt')
        ]);
        $serviceItem->save();
        return redirect()->route('serviceItem.table')->with(
            'info',
            "De nieuwe dienst  '" . $request->input('title') . "' werdt toegevoegd."
        );
    }

    public function getDeleteServiceItem(int $id)
    {
        $serviceItem = ServiceItem::find($id);
        $title = $serviceItem->title;
        $serviceItem->delete();
        return redirect()->route('serviceItem.table')->with(
            'info',
            "De dienst '" . $title . "' werd verwijderd."
        );
    }

    public function getEditServiceItem(int $id)
    {
        $serviceItem = ServiceItem::find($id);
        return view(
            'serviceItem.edit',
            [
                'serviceItem' => $serviceItem,
                'serviceItem_id' => $id
            ]
        );
    }

    public function getUpdateServiceItem(Request $request)
    {
        $request->validate(
            [
                'title' => 'required',
                'descriptions' => 'nullable',
                'unitPrice' => 'required',
                'taxPercentageAsInt' => 'required|integer'
            ],
            [
                'title.required' => 'Gelieve een dienst titel in te vullen.',
                'unitPrice.required' => 'Gelieve een prijs in te vullen.',
                'unitPrice.numeric' => 'Gelieve een getal in tevullen voor de prijs.',
                'taxPercentageAsInt.required' => 'Gelieve een geheel getal in tevullen voor het BTW %.'
            ]
        );
        $serviceItem = ServiceItem::find($request->input('id'));
        $title = $serviceItem->title;
        $serviceItem->title = $request->input('title');
        $serviceItem->descriptions = $request->input('descriptions');
        $serviceItem->unitPrice = $request->input('unitPrice');
        $serviceItem->taxPercentageAsInt = $request->input('taxPercentageAsInt');
        $serviceItem->save();
        return redirect()->route('serviceItem.table')->with(
            'info',
            "De dienst '" . $title . "' werd aangepast."
        );
    }
}
