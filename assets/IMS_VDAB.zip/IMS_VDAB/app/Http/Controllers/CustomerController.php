<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function getCustomerById(int $id)
    {
        $customer = Customer::find($id);
        return $customer;
    }
    public function getCustomers()
    {
        $customers = Customer::orderby('id')->get();
        return view('customer.table', ['customers' => $customers]);
    }

    //ORM
    public function getCustomerRecords()
    {
        $customers = Customer::orderby('id')->get();
        return $customers;
    }

    public function getCreateCustomer()
    {
        return view('customer.create');
    }

    public function indexCustomerPaging(Request $request)
    {
        $filterResidence = $request->query('filterResidence');
        $filterOndernemingsnummer =$request->query('filterOndernemingsnummer');
        $filterKlant = $request->query('filterKlant');

        switch (true) {
            case ($filterResidence):
                $customers = Customer::Sortable()
                    ->where('customers.residence', 'like', '%' . $filterResidence . '%')
                    ->paginate(3);
                break;
            case ($filterOndernemingsnummer):
                $customers = Customer::Sortable()
                    ->where('customers.VATnumber', 'like', '%' . $filterOndernemingsnummer . '%')
                    ->paginate(3);
                break;
            case ($filterKlant):
                $customers = Customer::Sortable()
                    ->whereRaw(DB::raw("CONCAT(customers.firstName,' ',customers.lastName)  like '%$filterKlant%'"))
                    ->paginate(3);
                break;
            default:
                $customers = Customer::Sortable()->paginate(3);
        }
        
        return view('customer.table')->with(
            [
                'customers' => $customers,
                'filterResidence' => $filterResidence,
                'filterOndernemingsnummer' => $filterOndernemingsnummer,
                'filterKlant' => $filterKlant
            ]
        );
    }

    public function postCreateCustomer(Request $request)
    {
        $request->validate(
            [
                'firstName' => 'required|min:2',
                'lastName' => 'required|min:2',
                'VATnumber' => 'nullable|unique:customers',
                'address' => 'required|min:2',
                'residence' => 'required|min:2',
                'zip' => 'required|alpha_num',
                'email' => 'required|email|unique:customers',
                'phone' => 'nullable|unique:customers'
            ],
            [
                'firstName.required' => 'Gelieve een voornaam voor de klant in te vullen.',
                'lastName.required' => 'Gelieve een familienaam voor de klant in te vullen.',
                'address.required' => 'Gelieve het adres van de klant in te vullen.',
                'residence.required' => 'Gelieve de woonplaats van de klant in te vullen',
                'zip.required' => 'Gelieve de postcode van de klant in te vullen.',
                'email.email' => 'Gelieve een correct e-mailadres in te vullen.',
                'email.unique' => 'Het e-mailadres moet uniek zijn.',
                'VATnumber.unique' => 'De ondernemingsnummer moet uniek zijn.'
            ]
        );

        $customer = new Customer([
            'firstName' => $request->input('firstName'),
            'lastName' => $request->input('lastName'),
            'VATnumber' => $request->input('VATnumber'),
            'address' => $request->input('address'),
            'residence' => $request->input('residence'),
            'zip' => $request->input('zip'),
            'email' => $request->input('email'),
            'phone' => $request->input('phone')
        ]);
        $customer->save();
        return redirect()->route('customer.table')->with(
            'info',
            'Nieuwe klant "' . $request->input('firstName') . ' ' . $request->input('lastName') . '" toegevoegd.'
        );
    }

    public function getCustomerEdit(int $id)
    {
        $customer = Customer::find($id);
        return view(
            'customer.edit',
            [
                'customer' => $customer,
                'customerId' => $id
            ]
        );
    }

    public function getCustomerDelete($id)
    {
        $customer = Customer::find($id);
        $firstName = $customer->firstName;
        $lastName = $customer->lastName;
        $customer->delete();
        return redirect()->route('customer.table')->with(
            'info',
            'De klant "' . $firstName . ' ' . $lastName . '" werd verwijderd.'
        );
    }

    //|unique:customers werkt niet voor een update
    // hij ziet niet dat het over dezelfde klant gaat
    public function postCustomerUpdate(Request $request)
    {
        $request->validate(
            [
                'firstName' => 'required|min:2',
                'lastName' => 'required|min:2',
                'VATnumber' => 'nullable',
                'address' => 'required|min:2',
                'residence' => 'required|min:2',
                'zip' => 'required|alpha_num',
                'email' => 'required|email',
                'phone' => 'nullable'
            ],
            [
                'firstName.required' => 'Gelieve een voornaam voor de klant in te vullen.',
                'lastName.required' => 'Gelieve een familienaam voor de klant in te vullen.',
                'address.required' => 'Gelieve het adres van de klant in te vullen.',
                'residence.required' => 'Gelieve de woonplaats van de klant in te vullen.',
                'zip.required' => 'Gelieve de postcode van de klant in te vullen.',
                'email.email' => 'Gelieve een correct e-mailadres in te vullen.',
                'email.unique' => 'Het e-mailadres moet uniek zijn.',
                'VATnumber.unique' => 'De ondernemingsnummer moet uniek zijn.'
            ]
        );

        $customer = Customer::find($request->input('id'));
        $firstName = $customer->firstName;
        $lastName = $customer->lastName;
        $customer->firstName  = $request->input('firstName');
        $customer->lastName = $request->input('lastName');
        $customer->VATnumber = $request->input('VATnumber');
        $customer->address = $request->input('address');
        $customer->residence = $request->input('residence');
        $customer->zip = $request->input('zip');
        $customer->email = $request->input('email');
        $customer->phone = $request->input('phone');
        $customer->save();
        return redirect()->route('customer.table')->with(
            'info',
            'De klant "' . $firstName . ' ' . $lastName . '" werd aangepast.'
        );
    }
}
