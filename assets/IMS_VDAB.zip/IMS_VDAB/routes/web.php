<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\InvoiceController;
use App\Http\Controllers\ServiceItemController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('', function () {
    return view('home');
})->name('home');

Route::get('/home', function () {
    return view('home');
})->name('home');

//Invoice
Route::group(['prefix' =>"invoice", 'middleware' =>['auth']],function(){
    Route::get('/', [InvoiceController::class, 'show'])->name('vendor.invoices.templates.default.blade.php');
    Route::get('invoice/{customerId}', [InvoiceController::class, 'showByCustomerId'])->name('factuurByCustomer');
    Route::get('create', [InvoiceController::class, 'createInvoice'])->name('invoice.create');
    Route::post('create', [InvoiceController::class, 'showWithRequest'])->name('invoice.create');
    Route::get('table',[InvoiceController::class, 'indexDocumentsPaging'])->name('invoice.table');
    Route::get('/{id}',[InvoiceController::class, 'getHistoricDocument'])->name('invoice.document');
});

//customers
Route::group(['prefix' =>"customer", 'middleware' =>['auth']],function(){
    Route::get('table', [CustomerController::class, 'indexCustomerPaging'])->name('customer.table');
    Route::get('create', [CustomerController::class, 'getCreateCustomer'])->name('customer.create');
    Route::post('create', [CustomerController::class, 'postCreateCustomer'])->name('customer.create');
    Route::get('delete/{id}', [CustomerController::class, 'getCustomerDelete'])->name('customer.delete');
    Route::get('edit/{id}', [CustomerController::class, 'getCustomerEdit'])->name('customer.edit');
    Route::post('update', [CustomerController::class, 'postCustomerUpdate'])->name('customer.update');
});

//Services
Route::group(['prefix' =>"serviceItem", 'middleware' =>['auth']],function(){
    Route::get('table', [ServiceItemController::class, 'indexServiceItemsPaging'])->name('serviceItem.table');
    Route::get('create', [ServiceItemController::class, 'getCreateServiceItem'])->name('serviceItem.create');
    Route::post('create', [ServiceItemController::class, 'postCreateServiceItem'])->name('serviceItem.create');
    Route::get('delete/{id}', [ServiceItemController::class, 'getDeleteServiceItem'])->name('serviceItem.delete');
    Route::get('edit/{id}', [ServiceItemController::class, 'getEditServiceItem'])->name('serviceItem.edit');
    Route::post('update', [ServiceItemController::class, 'getUpdateServiceItem'])->name('serviceItem.update');
});

Auth::routes();
//TODO: facturen bundelen en exporten per jaar 
//TODO: punt of komma notie voor bedragen validatie
//TODO: Het aantal keer als input veld voorzien voor het factuur
//TODO: dubbele telefoonnummer controle -> test
//TODO: een oplossing zoeken om een backup te nemen van de database