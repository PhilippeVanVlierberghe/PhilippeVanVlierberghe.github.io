

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <form target="_blank" action="<?php echo e(route('invoice.create')); ?>" method="post">
                    <div class="form-group-container">
                        
                        <div class="form-group">
                            <label for="documentType">Document:</label>
                            <select name="documentType">
                                <option value="" disabled selected>Kies een documenttype...</option>
                                <option value="Factuur">Factuur</option>
                                <option value="Offerte">Offerte</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="documentDate">Datum:</label>
                            <input type="date" name="documentDate" value="<?php echo e(date('Y-m-d')); ?>">
                        </div>

                        <div class="form-group">
                            <label for="document_code">Factuurnummer:</label>
                            <input type="text" name="document_code" value="<?php echo e($lastDocument_code); ?>">
                        </div>

                        <div class="form-group">
                            <label for="customerId">Klant:</label>
                            <select name="customerId" id="customerId">
                                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($customer->id); ?>">
                                        <?php echo e($customer->firstName . ' ' . $customer->lastName); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <br />
                    <div class="form-group">
                        <div class="tableContainer">
                            <div class="scroll">
                                <table>
                                    <thead>
                                        <tr>
                                            <th class="tableHidden"><label for="invoiceItem_id[]"></label></th>
                                            <th><label for="invoiceItem_add[]"><svg xmlns="http://www.w3.org/2000/svg"
                                                        width="16" height="16" fill="currentColor"
                                                        class="bi bi-check" viewBox="0 0 16 16">
                                                        <path
                                                            d="M10.97 4.97a.75.75 0 0 1 1.07 1.05l-3.99 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.267.267 0 0 1 .02-.022z" />
                                                    </svg></label></th>
                                            <th><label for="invoiceItem_title[]">Opdracht</label></th>
                                            <th><label for="invoiceItem_descriptions[]">Toelichting</label></th>
                                            <th><label for="invoiceItem_unitPrice[]">Prijs in €</label></th>
                                            <th><label for="invoiceItem_taxPercentageAsInt[]">BTW in %</label></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $invoiceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $invoiceItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="tableHidden"><input class="tableHidden" type="text"
                                                        name="invoiceItem_id[]" value="<?php echo e($invoiceItem->id); ?>"></td>
                                                </td>
                                                <td class="ExtrasmallTableField"><input class="form-check-input"
                                                        type="checkbox" name="invoiceItem_add<?php echo e($key); ?>[]">
                                                </td>
                                                <td><input class="invoiceItem_title" type="text"
                                                        name="invoiceItem_title[]" value="<?php echo e($invoiceItem->title); ?>"></td>
                                                <td>
                                                    <textarea rows="3" cols="50" name="invoiceItem_descriptions[]"><?php echo str_replace('<br />', "\n", $invoiceItem->descriptions); ?></textarea>
                                                </td>
                                                <td class="smallTableField"><input class="col-4" type="text"
                                                        name="invoiceItem_unitPrice[]"
                                                        value="<?php echo e($invoiceItem->unitPrice); ?>">
                                                </td>
                                                <td class="smallTableField"><input class="col-2" type="text"
                                                        name="invoiceItem_taxPercentageAsInt[]"
                                                        value="<?php echo e($invoiceItem->taxPercentageAsInt); ?>"></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div><br />

                    <div class="form-group">
                        <label for="notes">Opmerkingen (optioneel):</label>
                        <textarea id="notes" class="form-control" name="notes" rows="4"></textarea>
                    </div>
                    <?php echo e(csrf_field()); ?>

                    <br />
                    <button type="submit" class="btn btn-primary">Maak document</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\IMS\resources\views/vendor/invoices/createInvoice.blade.php ENDPATH**/ ?>