

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('info')): ?>
            <div class="rowExtra">
                <div class="col-md-12">
                    <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
                </div>
            </div>
        <?php endif; ?>
        <p>
            <a class="btn btn-primary" href="<?php echo e(route('serviceItem.create')); ?>">Nieuwe dienst aanmaken</a>
        </p>
        <div class="tableContainer">
            <div class="tableFilter">
                <div class="row">
                    <div class="col">
                        <form class="form-inline" method="GET">
                            <div class="form-group">
                                <label for="filterDienst" class="col-form-label">Zoeken op dienst:</label>
                                <input type="text" class="form-control" id="filterDienst" name="filterDienst"
                                    placeholder="Dienst..." value="<?php echo e($filterDienst); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <br>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('id', '#'));?></th>
                        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('title', 'Dienst'));?></th>
                        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('descriptions', 'Toelichting'));?></th>
                        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('unitPrice', 'Prijs'));?> €</th>
                        <th scope="col"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('taxPercentageAsInt', 'BTW %'));?></th>

                        <th><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-pencil-square" viewBox="0 0 16 16">
                                <path
                                    d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                <path fill-rule="evenodd"
                                    d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                            </svg></th>
                        <th><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                class="bi bi-trash" viewBox="0 0 16 16">
                                <path
                                    d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z" />
                                <path fill-rule="evenodd"
                                    d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" />
                            </svg></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $serviceItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviceItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($serviceItem->id); ?></th>
                            <td><?php echo e($serviceItem->title); ?></td>
                            <td><?php echo nl2br($serviceItem->descriptions); ?></td>
                            <td><?php echo e($serviceItem->unitPrice); ?></td>
                            <td><?php echo e($serviceItem->taxPercentageAsInt); ?></td>
                            <td><a href="<?php echo e(route('serviceItem.edit', ['id' => $serviceItem->id])); ?>">Edit</a></td>
                            <td><a href="<?php echo e(route('serviceItem.delete', ['id' => $serviceItem->id])); ?>">Delete</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="paginationContainer">
                <div><?php echo e($serviceItems->appends($_GET)->links('partials.custom_pagination')); ?></div>
            </div>
            <p>U ziet <?php echo e($serviceItems->count()); ?> van de <?php echo e($serviceItems->total()); ?> dienst(en).</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Phili\Documents\GitHub\Invoice management system\deskresearch\IMS_VDAB\resources\views/serviceItem/table.blade.php ENDPATH**/ ?>