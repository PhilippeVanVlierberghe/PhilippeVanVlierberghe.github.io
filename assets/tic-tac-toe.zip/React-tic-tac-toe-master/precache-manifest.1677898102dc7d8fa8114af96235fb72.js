self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4784076f6813e66e2b79a8f836bfe000",
    "url": "/React-tic-tac-toe/index.html"
  },
  {
    "revision": "35941b4fa7b59cf6581d",
    "url": "/React-tic-tac-toe/static/css/main.f695acee.chunk.css"
  },
  {
    "revision": "7144a41f7e6c783a7e97",
    "url": "/React-tic-tac-toe/static/js/2.83a1039e.chunk.js"
  },
  {
    "revision": "35941b4fa7b59cf6581d",
    "url": "/React-tic-tac-toe/static/js/main.497eccf5.chunk.js"
  },
  {
    "revision": "6240499778d78cd7a218",
    "url": "/React-tic-tac-toe/static/js/runtime-main.275a40c3.js"
  }
]);