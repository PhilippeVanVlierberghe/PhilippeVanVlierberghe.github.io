self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9d7967ee3d403084a7f43f922c88c80a",
    "url": "/Restful-API-call/index.html"
  },
  {
    "revision": "d1947ab9ddf12f113d02",
    "url": "/Restful-API-call/static/css/main.19d7fccc.chunk.css"
  },
  {
    "revision": "85bd1d70a2eb67c00396",
    "url": "/Restful-API-call/static/js/2.655bea82.chunk.js"
  },
  {
    "revision": "d1947ab9ddf12f113d02",
    "url": "/Restful-API-call/static/js/main.ce1264f5.chunk.js"
  },
  {
    "revision": "b56c7491fb86e181db45",
    "url": "/Restful-API-call/static/js/runtime-main.198c6f57.js"
  }
]);