import sun.audio.*;

import javax.sound.sampled.AudioInputStream;

public interface NoteInterface {
    //Duration
    public static final String HELE_NOOT = "hele noot"; // 4 tellen
    public static final String HALVE_NOOT = "halve noot"; // 2 tellen
    public static final String KWART_NOOT = "kwart noot"; // 1 tel
    public static final String ACHTSTE_NOOT = "achtste noot"; // 0.5 tel
    public static final String ZESTIENDE_NOOT = "zestiende noot"; //0.25 tel

    //Name pitch names - So-Fa Syllables
    public static final String C = "c"; //do
    public static final String D = "d"; //re
    public static final String E = "e"; //mi
    public static final String F = "f"; //fa
    public static final String G = "g"; //sol
    public static final String A = "a"; //la
    public static final String B = "b"; //ti

    //Name pitch names - So-Fa Syllables
    public static final String DO = "do"; //d
    public static final String DO_HOOG ="hoge do"; //d
    public static final String RE = "re"; //re
    public static final String MI = "mi"; //mi
    public static final String FA = "fa"; //fa
    public static final String SOL = "sol"; //sol
    public static final String LA = "la"; //la
    public static final String SI = "si"; //ti

    public String getDurationName();

    public String getNoteName();

    public double getDuration();

    public String printNote();

    public String getSoFaSyllable();

}
