import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.net.URL;

public class AudioCreator {
    public static void playSound(URL soundURl) {
        try {
            if (!("").equals(soundURl.getPath())) {
                AudioInputStream stream = AudioSystem.getAudioInputStream(soundURl);
                Clip clip = AudioSystem.getClip();
                clip.open(stream);
                clip.start();

            } else {
                System.out.println("Can't find file");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
