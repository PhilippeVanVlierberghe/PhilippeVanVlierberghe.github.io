import java.io.File;
import java.net.URL;
import java.util.Random;

public class Note implements NoteInterface {
    private NoteName noteName;
    private NoteValue noteValue;
    //private File noteAudioFile;
    private URL noteSoundUrl;

    Note() {
        //create random note
        Random r = new Random();
        switch (r.nextInt(8)) {
            case 0:
                noteName = new NoteName(NoteInterface.DO);
                noteSoundUrl = getClass().getResource("do.wav");
                break;
            case 1:
                noteName = new NoteName(NoteInterface.RE);
                noteSoundUrl = getClass().getResource("re.wav");
                break;
            case 2:
                noteName = new NoteName(NoteInterface.MI);
                noteSoundUrl = getClass().getResource("mi.wav");
                break;
            case 3:
                noteName = new NoteName(NoteInterface.FA);
                noteSoundUrl = getClass().getResource("fa.wav");
                break;
            case 4:
                noteName = new NoteName(NoteInterface.SOL);
                noteSoundUrl = getClass().getResource("sol.wav");
                break;
            case 5:
                noteName = new NoteName(NoteInterface.LA);
                noteSoundUrl = getClass().getResource("la.wav");
                break;
            case 6:
                noteName = new NoteName(NoteInterface.SI);
                noteSoundUrl = getClass().getResource("si.wav");
                break;
            case 7:
                noteName = new NoteName(Note.DO_HOOG);
                noteSoundUrl = getClass().getResource("do-octave.wav");
                break;
            default:
                noteName = null;
    }
        //random note value
        switch (r.nextInt(5))
        {
            case 0:
                noteValue = new NoteValue(NoteInterface.HELE_NOOT);
                break;
            case 1:
                noteValue = new NoteValue(NoteInterface.HALVE_NOOT);
                    break;
                case 2:
                noteValue = new NoteValue(NoteInterface.KWART_NOOT);
                break;
            case 3:
                noteValue = new NoteValue(NoteInterface.ACHTSTE_NOOT);
                break;
            case 4:
                noteValue = new NoteValue(NoteInterface.ZESTIENDE_NOOT);
                break;
            default:
                noteValue = null;
        }
    }

    @Override
    public String getDurationName() {
        return this.noteValue.getDurationName();
    }

    @Override
    public String getNoteName() {
        return noteName.getSoFaSyllable() + " <-> " +
                noteName.getPitchNames();
    }

    @Override
    public String getSoFaSyllable() {
        return noteName.getSoFaSyllable();
    }


    @Override
    public double getDuration() {
        return noteValue.getDuration();
    }

    @Override
    public String printNote() {
        return  this.noteValue.getDurationName() + " " +
                this.noteName.getSoFaSyllable() + " = " +
                this.noteValue.getDuration();
    }

    /*
    public File getNoteAudioFile() {
        return noteAudioFile;
    }

    public void setNoteAudioFile(File noteAudioFile) {
        this.noteAudioFile = noteAudioFile;
    }
*/
    public URL getNoteSoundUrl() {
        return noteSoundUrl;
    }

    public void setNoteSoundUrl(URL noteSoundUrl) {
        this.noteSoundUrl = noteSoundUrl;
    }
}
