import javax.swing.JFrame;

public class Run {

    public static void main(String[] args) {
        String version = "0.9";
        Note randomNote = new Note();
        JFrame f = new JFrame("General music theory " + version );
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        NotePanel notePanel = new NotePanel();
        f.add(notePanel);
        f.setSize(310,280);
        f.setResizable(false);
        f.setVisible(true);
    }
}
