public class NoteName{
    private String SoFaSyllable;
    private String pitchNames;

    public NoteName(String newSoFaSyllable)
    {

        switch (newSoFaSyllable) {
            case NoteInterface.DO_HOOG:
                this.SoFaSyllable = NoteInterface.DO_HOOG;
                this.pitchNames = NoteInterface.C;
                break;
            case NoteInterface.DO:
                this.SoFaSyllable = NoteInterface.DO;
                this.pitchNames = NoteInterface.C;
                break;
            case NoteInterface.RE:
                this.SoFaSyllable = NoteInterface.RE;
                this.pitchNames = NoteInterface.D;
                break;
            case NoteInterface.MI:
                this.SoFaSyllable = NoteInterface.MI;
                this.pitchNames = NoteInterface.E;
                break;
            case NoteInterface.FA:
                this.SoFaSyllable = NoteInterface.FA;
                this.pitchNames = NoteInterface.F;
                break;
            case NoteInterface.SOL:
                this.SoFaSyllable = NoteInterface.SOL;
                this.pitchNames = NoteInterface.G;
                break;
            case NoteInterface.LA:
                this.SoFaSyllable = NoteInterface.LA;
                this.pitchNames = NoteInterface.A;
                break;
            case NoteInterface.SI:
                this.SoFaSyllable = NoteInterface.SI;
                this.pitchNames = NoteInterface.B;
                break;
            default: System.out.println("Geef een correct noot in (SOFA SYLLABLES)");
        }

    }

    /*
    NoteName(String newSoFaSyllable, String newPitchNames )
    {
        this.SoFaSyllable = newSoFaSyllable;
        this.pitchNames = newPitchNames;
    }
    */

    public String getSoFaSyllable() {
        return SoFaSyllable;
    }

    public String getPitchNames() {
        return pitchNames;
    }
}
