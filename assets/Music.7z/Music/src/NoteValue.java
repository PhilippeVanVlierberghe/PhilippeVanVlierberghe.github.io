public class NoteValue {
    private double duration;
    private String durationName;

    public NoteValue (String newDurationName)
    {
        switch (newDurationName)
        {
            case NoteInterface.HELE_NOOT :
                this.durationName = NoteInterface.HELE_NOOT;
                this.duration = 4.0;
                break;
            case NoteInterface.HALVE_NOOT :
                this.durationName = NoteInterface.HALVE_NOOT;
                this.duration = 2.0;
                break;
            case NoteInterface.KWART_NOOT :
                this.durationName = NoteInterface.KWART_NOOT;
                this.duration = 1.0;
                break;
            case NoteInterface.ACHTSTE_NOOT :
                this.durationName = NoteInterface.ACHTSTE_NOOT;
                this.duration = 0.5;
                break;
            case NoteInterface.ZESTIENDE_NOOT :
                this.durationName = NoteInterface.ZESTIENDE_NOOT;
                this.duration = 0.25;
                break;
        }
    }

    public double getDuration() {
        return duration;
    }

    public String getDurationName() {
        return durationName;
    }
}
