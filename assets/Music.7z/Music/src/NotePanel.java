import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.HashMap;


public class NotePanel extends JPanel {
    private static final HashMap<String, Note> notesByName = new HashMap<>() ;
    private JButton bNext = new JButton("START");
    private JTextField tAwnser1 = new JTextField("Welke noot ?",5);
    private JTextField tAwnser2 = new JTextField("Welke nootwaarde ?",5);
    private JTextPane  tScorebord = new JTextPane();
    private Note n;
    private Integer notePositie;
    private Image key;
    private Boolean AnswerGate1 = false;
    private Boolean AnswerGate2 = false;
    private int score = 0, teller = 0,  hoogteNotenbalk = 25;;

    //FlyWeight Constructor
    public NotePanel()
    {
        key = Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("sleutel.gif"));
        setLayout(null);
        tAwnser1.setSize(132,25);
        tAwnser1.setLocation(10,180);
        tAwnser1.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(("Welke noot ?").equals(tAwnser1.getText())) {
                    tAwnser1.setText("");
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if(tAwnser1.getText().length()==0) {
                    tAwnser1.setText("Welke noot ?");
                }
            }
        });
        tAwnser1.addActionListener(e -> {
            if(tAwnser1.getText().toLowerCase().equals(n.getSoFaSyllable()))
            {
                tAwnser1.setBackground(Color.green);
                AnswerGate1 = true;
                if(AnswerGate2)
                {
                    bNext.doClick();
                    score++;
                }
            }
            else
            {
                tAwnser1.setBackground(Color.red);
                AnswerGate1 = false;
            }
            teller++;
        });

        tAwnser2.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if(("Welke nootwaarde ?").equals(tAwnser2.getText())) {
                    tAwnser2.setText("");
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if(tAwnser2.getText().length()==0) {
                    tAwnser2.setText("Welke nootwaarde ?");
                }
            }
        });

        tAwnser2.addActionListener(e -> {
            //System.out.println(n.getDuration());
            //System.out.println("Awnser 2: " + tAwnser2.getText());
            if(Double.valueOf(tAwnser2.getText().toLowerCase()).equals(n.getDuration()))
            {
                tAwnser2.setBackground(Color.green);
                AnswerGate2 = true;
                if(AnswerGate1)
                {
                    bNext.doClick();
                    score++;
                }
            }
            else
            {
                tAwnser2.setBackground(Color.red);
                AnswerGate2 = false;
            }
            teller++;
        });
        tAwnser2.setSize(132,25);
        tAwnser2.setLocation(160,180);
        tAwnser1.setVisible(false);
        tAwnser2.setVisible(false);

        tScorebord.setSize(283,25);
        tScorebord.setLocation(10,hoogteNotenbalk - 30);
        tScorebord.setEditable(false);
        Font font = new Font("Courier", Font.BOLD,12);
        tScorebord.setFont(font);
        SimpleAttributeSet attribs = new SimpleAttributeSet();
        StyleConstants.setAlignment(attribs, StyleConstants.ALIGN_CENTER);
        tScorebord.setParagraphAttributes(attribs,true);
        bNext.setSize(283,25);
        bNext.setLocation(10,210);
        bNext.addActionListener(e -> {
            tAwnser1.setVisible(true);
            tAwnser2.setVisible(true);
            if(("START").equals(bNext.getText()))
            {
                bNext.setText("NEXT");
            }

            n = new Note();
            paintNewNote(n);
            restPanel();
            repaint();
        });
        add(bNext);
        add(tAwnser1);
        add(tAwnser2);
        //add(tScorebord);
    }

    //Flyweight
    public void paintNewNote(Note newNote)
    {
        this.n = notesByName.get(newNote.getSoFaSyllable()+ "_" +newNote.getDurationName());

        if( n == null)
        {
            n = newNote;
            notesByName.put(newNote.getSoFaSyllable()+"_"+newNote.getDurationName(),n);
        }else
        {
            n = notesByName.get(newNote.getSoFaSyllable()+"_"+newNote.getDurationName());
        }
    }

    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        this.setBackground(Color.WHITE);
        g.setColor(Color.BLACK);

        //Teken de notenbalk
        g.drawLine(25,hoogteNotenbalk,250,hoogteNotenbalk);
        g.drawLine(25,hoogteNotenbalk + 25, 250 ,hoogteNotenbalk + 25);
        g.drawLine(25,hoogteNotenbalk + 50,250,hoogteNotenbalk + 50);
        g.drawLine(25,hoogteNotenbalk + 75,250,hoogteNotenbalk + 75);
        g.drawLine(25,hoogteNotenbalk + 100 ,250,hoogteNotenbalk + 100);
        g.drawImage(key,25,hoogteNotenbalk - 20,40,150,this);

        if(!("START").equals(bNext.getText())) {
            //Bepaal positie van de noot
            switch (n.getSoFaSyllable()) {
                case Note.DO_HOOG:
                    notePositie = hoogteNotenbalk + 27;
                    break;
                case Note.DO:
                    notePositie = hoogteNotenbalk + 110;
                    break;
                case Note.RE:
                    notePositie = hoogteNotenbalk + 100;
                    break;
                case Note.MI:
                    notePositie = hoogteNotenbalk + 90;
                    break;
                case Note.FA:
                    notePositie = hoogteNotenbalk + 77;
                    break;
                case Note.SOL:
                    notePositie = hoogteNotenbalk + 65;
                    break;
                case Note.LA:
                    notePositie = hoogteNotenbalk + 52;
                    break;
                case Note.SI:
                    notePositie = hoogteNotenbalk + 40;
                    break;
            }
            Graphics2D g2 = (Graphics2D) g;
            g2.setStroke(new BasicStroke(3));
            g2.setColor(Color.BLUE);

            //Bepaal vorm van de noot
            switch (n.getDurationName()) {
                case Note.HELE_NOOT:
                    g2.drawOval(125, notePositie, 20, 20);
                    if((Note.DO).equals(n.getSoFaSyllable())) {
                        g2.drawLine(120, 145, 150, 145);
                    }
                    break;
                case Note.HALVE_NOOT:
                    g2.drawOval(125, notePositie, 20, 20);
                    if((Note.DO_HOOG).equals(n.getSoFaSyllable()))
                    {
                        g2.drawLine(125, notePositie +10, 125, notePositie + 50);
                    }
                    else
                    {
                        g2.drawLine(145, notePositie - 35, 145, notePositie + 10);
                    }
                    break;
                case Note.KWART_NOOT:
                    g2.fillOval(125, notePositie, 20, 20);
                    if((Note.DO_HOOG).equals(n.getSoFaSyllable()))
                    {
                        g2.drawLine(125, notePositie +10, 125, notePositie + 50);
                    }
                    else
                    {
                        g2.drawLine(145, notePositie - 35, 145, notePositie + 10);
                    }
                    break;
                case Note.ACHTSTE_NOOT:
                    g2.fillOval(125, notePositie, 20, 20);

                    if((Note.DO_HOOG).equals(n.getSoFaSyllable()))
                    {
                        g2.drawLine(125, notePositie +10, 125, notePositie + 50);
                        g2.drawLine(128,notePositie +50,145,notePositie + 50);
                    }
                    else
                    {
                        g2.drawLine(145,notePositie - 35,145,notePositie + 10);
                        g2.drawLine(145,notePositie - 35,155,notePositie - 35);
                    }
                    break;
                case Note.ZESTIENDE_NOOT:
                    g2.fillOval(125, notePositie, 20, 20);

                    if((Note.DO_HOOG).equals(n.getSoFaSyllable()))
                    {
                        g2.drawLine(125, notePositie +10, 125, notePositie + 50);
                        g2.drawLine(128,notePositie +40,145,notePositie + 40);
                        g2.drawLine(128,notePositie +50,145,notePositie + 50);
                    }
                    else
                    {
                        g2.drawLine(145,notePositie - 35,145,notePositie + 10);
                        g2.drawLine(145,notePositie - 35,155,notePositie - 35);
                        g2.drawLine(145,notePositie - 25,155,notePositie - 25);
                    }
                    break;
            }

            AudioCreator audioCreator = new AudioCreator();
            audioCreator.playSound(n.getNoteSoundUrl());
            g.setColor(Color.BLUE);
            tScorebord.setText(score + " / " + teller);
        }
    }

    private void restPanel()
    {
        tAwnser1.setText("Welke noot ?");
        tAwnser1.setBackground(null);
        tAwnser2.setText("Welke nootwaarde ?");
        tAwnser2.setBackground(null);
        AnswerGate1 = false;
        AnswerGate2 = false;
    }
}

